本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=16&event=123

Title:Flashdance [Gimmick7]
Music:litmus*
Chart:hyuki

Notes:1228
Total:300

とある方へ向けた差分です。
内容はいつものギミック譜面ですが、少しだけその方の譜面を意識しているとかなんとか。