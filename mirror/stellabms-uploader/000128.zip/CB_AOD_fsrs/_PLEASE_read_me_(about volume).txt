﻿日本語
同梱された追加キー音(oggファイル)を本体フォルダに一緒に入れてください。
アレンジ差分ですので、全てのズレは意図的です。 基盤となるファイルは.base拡張子で同梱しました。
キー音の音圧がかなり大きいため、音圧が0dBを超えてプレイ環境によってプレイ時に音が割れることがあります。
このような場合は、次のような処置のいずれかを取ることができます。
1.LR2設定でplay_volumeからKEYとBGM項目をすべて50%以下に設定
2. oggをwavに変換後、bvlmに-300%dB程度ボリュームを調節します。
3. 下リンクから新しい本体をダウンロードします。 (追加キー音と差分同梱)
2次配布は以下のSoundcloudのCreative Commonsに基づきます。

한국어
동봉된 추가 키음(ogg 파일)을 본체 폴더에 같이 넣어주세요.
어레인지 차분이므로 모든 즈레는 의도적입니다. 기반이 되는 파일은 .base 확장자로 동봉했습니다.
키음의 볼륨이 상당히 크기 때문에 음압이 0dB를 초과하여 플레이 환경에 따라 플레이 시 음이 뭉개지는 경우가 있습니다.
이럴 때는 다음과 같은 조치 중 하나를 취할 수 있습니다.
1. LR2 설정 내에서 플레이 볼륨에서 KEY와 BGM 항목을 모두 50% 이하로 설정
2. ogg를 wav로 변환 후, bvlm으로 -300%dB 정도 볼륨을 조절합니다.
3. 하단 링크에서 새로운 본체를 다운로드 합니다. (추가 키음, 차분 포함)
2차배포는 아래 Soundcloud의 Creative Commons에 의거합니다.

Links
本体URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=592&event=110
Volume modified 本体 URL: https://www.dropbox.com/s/033q8q3w2tht6p0/Angel%20Of%20Darkness%20-2016ReEdit-.zip?dl=1
Soundcloud: https://soundcloud.com/kuro_zummer/aodex_pre

https://fsrs.github.io/