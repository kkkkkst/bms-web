本体 : https://web.archive.org/web/20170220105918/https://dl.dropboxusercontent.com/u/60346274/r-18/Neun_jack_%CF%89_cm3d2_ogg.zip

犬の声の出処は…
https://www.looperman.com/loops/detail/131032/between-a-dog-and-a-wolf-120bpm-weird-vocal-loop と
Lime様の「Smiling」からです。問題になると措置を取ります。←好加減

差分作者のMary_Sue's page : https://darksabun.github.io/Mary_Sue/
あるいは、https://twitter.com/MarySue_BMS / marysuebms@gmail.com にどうぞ