Starry Cadence[AFTERGLOW]
TiS / obj: Mary_Sue

本体リンク：https://cineraria-studio.com/?page_id=53
推定レベル：★7-8?
starry_cadence(a).bms基準ズレ抜けなし。

よろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/02/04