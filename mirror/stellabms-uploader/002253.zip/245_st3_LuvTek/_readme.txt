https://manbow.nothing.sh/event/event.cgi?action=More_def&num=245&event=140

DIFFICULTY: st3
NOTES: 2300
TOTAL: 300
JUDGERANK: NORMAL

同梱_audiovisual基準