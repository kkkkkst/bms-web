本体→https://web.archive.org/web/20030810094555/http://members16.cool.ne.jp/~narve/music/eternal.html

終盤のソフランを消してるのでズレが検出されますが意図的なものです