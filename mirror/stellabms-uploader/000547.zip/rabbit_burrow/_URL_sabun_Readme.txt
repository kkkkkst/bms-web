本体URL：https://pmcc.nekokan.dyndns.info/pmcc2/download.html
単品：http://sunaneko.iptime.org/BMS_Library/rabbit%20burrow%20%28by%20maki%20%28original%ef%bc%9awatson%29%29.rar

追加音源を全て同じフォルダに入れてください。