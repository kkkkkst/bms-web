---Song Information---

Title:せんせーしょん！

Composer:Sidou feat.妃苺

Song URL:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=306&event=133

---Chart Information---

Chart Title:[W], [LN-W]

Obj:w

Difficulty:◆F地力（★1）, ◆F2(◆10)? 

Judge Rank:EASY, EASY

Notes:1854(85LN), 1488(586LN)

Total:460, 402

---Coment---

[W]
This chart was actually made before the LN festival event (around February). I didn't want to publish it at the time, because I was thinking of making a LN chart for this song and releasing [W] + [LN-W] together.
When the LN festival event was announced. I thought it was a good opportunity to start making the [LN-W] chart.

せんせーしょん！ is a very drum-focused song. There are multiple drum bursts in the song that can be incredibly fun to play if charted well.
I think the right combination of fast trills and jacks can give the player the feeling of hitting the drums.
The drum bursts set the baseline for the difficulty of the song, which would be around ★1.
This song doesn't have a lot of notes however, so I had to take extra care to ensure that the rest of the chart was balanced to approximately the same level.

Pattern-wise, the bass guitar obviously should be charted to anchor notes, and I use large chords to emphasize the sounds of the brass instruments. I originally wanted to use LNs for the brass instruments, but I think that would have made the chart have too many LNs. Large chords are a good substitute.
In order to match the difficulty of the drum bursts, I relied on using tricky anchor patterns and large chords to keep the rest of the chart sufficiently challenging.
LNs are generally used for the break sections of the song.

There was one measure where I decided to chart the notes to the vocals instead. Grab your pitchforks.

Total time spent: Around 2-3 weeks?

[LN-W]
Now I can finally go ham with the LNs.
While the [W] chart focused on the drums, this chart instead focuses on the brass and guitar. There were a few sections where the patterns are drum-focused, but I mostly prioritized the more melodic instruments. I feel like LN charts tend to focus more on the melodies, while rice charts tend to focus more on the drums.

In this chart, the amount of rice notes correspond to how much prominence the drums have in each section. For example, on measure 29, there is a hard switch from rice notes to full LN, as the vocals have the focus in this section. The rice notes gradually start to come back in towards the end of the section as the focus gradually switches back to the drums in the song. Something similar happens during the guitar solo later in the song.

Similar to [W], there is also one short section where I decided to focus on the vocals instead. Heh. I feel like I like to arbitrarily switch my focus between instruments, depending on which instrument my brain focuses on in each section. It may seem awkward to some, but I think this also adds variety to the charting. I think variety is important.

Also, I had to remove a lot of cymbal scratches, because the scratches don't really work very well with long notes, especially for players like me who pinky scratch. I tried to keep the scratches whenever I could, though. I also tried to make sure this chart was also fair on random. I'm not sure if it's necessary to do so though.

Total time spent: ~1.5 weeks

zure check: _Normal.bms

---Other---

Website:https://wcko87.github.io/
Twitter:https://twitter.com/wcko87
自作譜面の難易度表:https://wcko87.github.io/bms-table/obj-w.html