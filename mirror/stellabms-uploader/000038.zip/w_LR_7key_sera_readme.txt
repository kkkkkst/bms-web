WAV spliced keysounds: https://seraphin.xyz/static/sabun/w_LR_7key_sera_wav.zip
My charts: https://seraphin.xyz/sabun.html
T/N=0.46