SAKURA [MARYTHER]
by ANKAKE

本体：https://venue.bmssearch.net/bmstukuru2023/54
推定レベル：★21? (st1?)
_btatuku23_sakura_7a基準、発生した全てのズレ抜けは音切れのせいで発生したものです。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/07/28
