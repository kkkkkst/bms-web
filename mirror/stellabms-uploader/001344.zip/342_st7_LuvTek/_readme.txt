URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=342&event=137

Difficulty: st7
Please download the lastest version of BMS to play the piano keysounds properly.
피아노 키음의 정상재생을 위해 최신 버전의 BMS 본체를 다운로드해주세요.