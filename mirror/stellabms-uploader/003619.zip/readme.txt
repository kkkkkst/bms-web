https://manbow.nothing.sh/event/event.cgi?action=More_def&num=21&event=119

0l.bmsと比較してズレなし
