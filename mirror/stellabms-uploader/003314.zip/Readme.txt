[Title]
喋喋喃喃 [Sweet]

[Difficulty]
st10

[Event URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=252&event=142

[BMS URL]
https://storage.googleapis.com/bof.reanisz.com/bof2023/%5BDONBRA_CO.LTD%5Dchochonannan_both_ver1.2.1.zip

[Comment]
連打差分
「[bms]chochonannan_7Key_SP_5_Insane.bms」を元に作成
上記同梱差分と比較してズレ抜け無し