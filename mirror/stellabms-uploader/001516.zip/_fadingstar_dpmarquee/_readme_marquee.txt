DP★2 Fading Star [Sparkling]

BMS URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=397&event=83

LR2IR
http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=307529

No Misalignment (fs_a.bms)