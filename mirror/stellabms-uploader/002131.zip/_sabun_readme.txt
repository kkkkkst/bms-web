本体は二つです。　adolf (by LU) + gasroom disco (by sopranotrom) 
To play this chart, you need two songs. adolf (by LU) + gasroom disco (by sopranotrom) 
이 패턴을 플레이하기 위해서는 두 개의 노래가 필요합니다. adolf (by LU) + gasroom disco (by sopranotrom) 

一つのフォルダに解凍してください。
Please unzip into one folder.
하나의 폴더에 압축해제해주세요.

adolf : http://www1.axfc.net/u/3145011
gasroom disco : http://cerebralmuddystream.nekokan.dyndns.info/BCII/BCII.zip