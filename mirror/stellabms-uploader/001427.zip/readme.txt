Song IR : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=408&event=137

Chart Name : あぶのーまる (real read : abnormal)
Difficult : sl3? 

Chart Comment : X

Personal Comment : 원래 다나까로 하려고 했지만 이게 현지화(로컬라이징)?하기가 매우 까다롭고
작곡가님 노리고 토탈치 271드립을 치기에는 노트수 드립으로는 난이도가 많이 갈릴것 같아서 같은 팀의 그 다른 곡으로 변경되었습니다.
난이도는 비정상적인 수준?으로만 조절했습니다.

변속을 삭제하고, 흰색과 파란색만 있는 편파적인 일부 배치만 조금 변형시켰습니다.