https://manbow.nothing.sh/event/event.cgi?action=More_def&num=189&event=116

DD_SPI.bmsと比較してズレなし
