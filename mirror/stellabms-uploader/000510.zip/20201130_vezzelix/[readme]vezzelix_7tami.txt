VEZZELiX [tami's creation]

bms by Reku Mochizuki : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=98&event=133
sabun author : tami
difficulty : ★5 / sl3

comment :
푸아아~~ (대충 참아왔던 말을 이제서야 말할 수 있게 됨을 나타내는 소리)
29일째의 no comment는 오늘 30일째, 즉 대망의 마지막날의 추진력을 얻기 위함이었다!!

파밭에만 출전하셨던 Reku Mochizuki 쨔마가 드디어 bof에 출전하셨기에 다시 한 번 있는 힘껏 차분을 만들어 보았습니다.
Another와 Inasne*의 중간 난이도쯤...으로 만드려고 했는데 어쩌다 보니 Inasne랑 비슷한 난이도가 되어 버렸네요 ㅋㅋ

아무튼 이번 《M-SPIN's BOFXVI Diary》 기획에 참여할 수 있게 되어 대단히 영광스럽게 생각합니다.
주최자 M-SPIN님과 게스트분들 모두 수고 많으셨습니다!
처음으로 stella급 난이도에 도전한 29일째의 'helemaal niet'과 더불어, 즐겁게 플레이해주세요오옷!!!!

* 앞으로는 Inasne가 아니라 insane으로 써 주세요 ㅎㅎ