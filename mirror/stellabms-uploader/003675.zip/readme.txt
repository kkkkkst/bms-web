同梱：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=2&event=141

同梱ANOTHER、および未配置ファイルとズレなし