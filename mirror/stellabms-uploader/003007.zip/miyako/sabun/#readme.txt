魔女様の曲変更差分(HEARTLESS)から作成　階段、同時、2連打複合 total高め。
宮子 [HEARTLESS]の差分DLはここから → https://stellabms.xyz/upload/2962

miyako_HEARTLESS_bass.bmsとズレチェック済
※038小節で検出されるズレは意図的なものです

Song URL : https://web.archive.org/web/20140224181206/http://plugout4.com/bof2012/[ULTIMATE-lopears]-miyako.zip