[Title]
Pixel Princess [Royal Dignity]

[Event URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=418&event=137

[Difficulty]
★★6(st10-11)

[Comment]
ディレイ差分
アレンジ差分のため、ディレイ付加によるズレがあります。
AnzuBMSDiff toolで同梱の「_pixel_princess_another7.bme」と比較して
意図しないズレがないことを確認済。