[Introduction]
「http://gnqg.rosx.net/upload/」
上記アップローダーで、06045にアップロードしたものの修正版

[Title]
Pandora [Forbidden Boxes]

[Event URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=153&event=137

[Difficulty]
★★5-6(st9-10)

[Comment]
連打とズレ物量
アレンジ差分のため、ディレイ等の付加によるズレがあります。
AnzuBMSDiff toolで同梱の「_ANOTHER.bms」と比較して
意図しないズレがないことを確認済。
