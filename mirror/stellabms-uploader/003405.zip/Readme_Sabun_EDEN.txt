E.V.E[EDEN]
SOMON / obj: Mary_Sue
本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=33&event=142
推定レベル：★20?

_No_pattern.bmsとズレ抜けなし。
よろしくお願いいたします。

2023/11/06
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)