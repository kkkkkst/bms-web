エヴァネセント
stuv + qfeileadh
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=23&event=142
推定レベル：Sl4

ズレ チェック :  __EV_03_SPH.bms/  __EV_99_XXX.meow とのズレなし


28番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)