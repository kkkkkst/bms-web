BMS by yassu (https://sound.jp/brilliantharmony/)
本体URL: http://sound.jp/brilliantharmony/s/bms/cp-ff4_golbeza.rar

[Scarmiglione] - ★4
[Cagnazzo] - ★8
[Barbariccia] - ★15
[Rubicante] - ★21
[Elemental Lords] - ★24