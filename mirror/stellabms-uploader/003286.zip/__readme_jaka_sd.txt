BilliumMoto - Revolution
[Starry Debut] sl11
obj: Jakads

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=203&event=142

BOF:NT差分企画: https://darksabun.github.io/event/bofnt/

__base.bmsとズレ無し