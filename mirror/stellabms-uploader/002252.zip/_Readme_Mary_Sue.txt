シミュラ・ラクラ [FADE]
本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=15&event=140
推定レベル：★21-22? (st1-2ぐらい）

4_Simula_Lacra.bms基準ズレ抜けなし。
最後に追加された動画はなんですか ⇒ 同梱_Patient_Chart.txtを読んでください！

Mary_Sue (https://darksabun.github.io/Mary_Sue/)
2022/12/09
