st7? Typical Fate [Icosahedron]
st3? Typical Fate [Dodecahedron]

NIKANON obj:Stellaおばさん

template.bmsと比較してズレ抜けなし

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=361&event=142
