本体URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=25&event=103

sweet_pop_[7-C_Another].bmeと比較してズレないことを確認しました。