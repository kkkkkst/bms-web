Call Of Alfine
ROKINA
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=44&event=142
推定レベル：★21? / St0~1?

ズレ チェック : _00_alfine.b, _04_alfine_a.bms とのズレなし


25番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)