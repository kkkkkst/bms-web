TITLE : SUPER STAR DISCO [7K CONVERT]
DIFFICULTY : ☆8～9

本体(BMSSP2008)→http://www.yamajet.com/bmssp/guide.html
bmssp2008_bmsonly.zip中の"knot10[one_star_disco_hq]"が本体です

"異常譜面遊戯"提出譜面

追加音源有り、ズレ抜けは追加音源による物以外は無し。
0note差分は声ネタが音切り前後両方配置してあるため注意。