﻿大体: https://venue.bmssearch.net/bmsshuin3/111

ABOUT MISALIGNED KEYSOUNDS:
The  editor's  maximum grid partition  caused some  keysounds
to be shifted only very slightly (basically inaudible) within
tight  bpm changes.  should  not be a  problem,  and  is  not
easily fixable.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~ http://tilde.town/~marie/ ~    く(｀･ω･´)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~