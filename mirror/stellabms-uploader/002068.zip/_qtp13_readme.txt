Fleeing Sunlight by ���݁[

[Sunset] Difficulty: st1~2 (��21~)

Uses template file.
Your standard qtp13 renda stream, with an explosive ending.
(Sorry for that awful pun, which is not even a pun...)

Song DL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=103&event=140