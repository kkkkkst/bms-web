
051 Weaponhuman [HELLO WORLD.]

判定：EASY　

Total：406

sl 0 中位を想定

交互、乱打、縦連など

本体同梱の
Weaponhuman_7keys_insane.bms
と比較でズレ無し

LR2とbeatorajaそれぞれ動作確認済み
__________________________________________

作曲/BGA：paraneumann 様

BMSイベントページ
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=20&event=131