ディレイ配置によるズレあり
本体:https://drive.google.com/drive/folders/1pJGq49KrF5St2Yfgp493oOKoDEIyZ6Hq
イベントURL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=211&event=96