曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=107&event=131

[00-make_your_own_chart].bms_と比較してズレないことを確認しました。

Thanks to Chart Tester
M-SPIN - https://fsrs.github.io/
七海 - https://egosa24.web.fc2.com/
Triforce - https://trfce.github.io/
hex - https://bms.hexlataia.xyz/
Mary_Sue - https://darksabun.github.io/Mary_Sue/