以下の差分を基に作成し、音ズレがないことを確認してます。

http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=81999