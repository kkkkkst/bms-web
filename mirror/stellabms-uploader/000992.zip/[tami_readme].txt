the nishikawaguchi [saitami-2000] / ★14
obj by tami
bms by itaojirou (http://manbow.nothing.sh/event/event.cgi?action=More_def&num=63&event=135)

additional sliced sounds included, no other ズレ