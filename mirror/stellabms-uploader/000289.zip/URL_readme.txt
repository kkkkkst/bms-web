曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=28&event=132

__your gaze.ca6yhと比較してズレないことを確認しました。