Myosotis [Lethe]
椿./movie.D・ENNY/ill.のこのこ
obj.Mary_Sue

for BOF:NT差分企画

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=200&event=142
推定レベル：★23? 
_tbking_myosotis_A.bmsとズレ抜けなし

2023/10/10