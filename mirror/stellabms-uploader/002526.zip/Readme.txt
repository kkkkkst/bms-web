[AnzuBMSDiff]

#077 01	(7 / 8)	#WAVES is missing in X. (b_Lead_auto2_v100l8-31o6a.wav)

[ES]의 길이가 1분이 넘어 정상적인 진행이 불가능하여 부득이하게 삭제하게 되었습니다.
[ES]の長さが1分を超えて正常に進行できないため、やむを得ず削除することになりました。
The length of [ES] was over a minute, so it was inevitable to delete it because it was impossible to proceed normally.


I was helped by papago translate.
Thank you for reading it.