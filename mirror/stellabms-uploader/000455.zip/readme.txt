BoobooBounce [Immortal]

URL : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=137&event=133
추정 난이도 : ★15?
코멘트 : 스크래치 추가 이외의 실 즈레는 없습니다.