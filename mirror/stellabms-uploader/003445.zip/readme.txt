URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=99&event=142

comment : SPI基準ズレX
대회 마감까지 2일밖에 남지 않아서 많이 뇌절치면서 st7?급까지로 맞춰보았습니다.
(12/02) 차분 기획 제출이 1주일 남아서 조금 약화시킨 st4?급도 추가였습니다. 해당 차분은 테스트를 거치지 않은 노트 난이도로 추정한 난이도입니다.

대회 마지막 날에 기획 제출 마감일인줄 알고 널버스 영상 따주신 M-SPIN님께 감사드립니다.
