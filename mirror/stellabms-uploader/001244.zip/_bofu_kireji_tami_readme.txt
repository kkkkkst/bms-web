DIARRHEA FROM HEAVEN. ASAP [pfither] / ★15

sabun by used_tami
bms by kireji : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=185&event=104

----------------------------------------------------------------------------------------------

우선 이 차분을 다운로드 받아 주셔서 감사드립니다.
이 곡과 bofxvii에 공개될 모 곡을 끝으로, 차분 채보 제작은 이제 영원히 그만두려고 합니다.
(누군가 제 차분 난이도표에 제안해 주신다면 다시 한 번 생각해 볼게요)

그리고 bms 제작 또한 이번 bofxvii를 끝으로 최소 1년간은 휴식하고 싶습니다.
제가 워낙 음악에 쓸데없는 미련이 많은지라 가능할지는 모르겠지만...

제 얘기는 여기까지 하고, bofu2015의 숨겨진 갓곡으로 차분 만들어 봤습니다.
kireji 이분 꽤 맛집이더라구요. 어나더 채보가 뭣같아서 그렇지
여러분들도 공감해 주신다면 기쁩니다.

그 동안 제 bms와 차분을 플레이 해 주신 여러분들께 다시 한 번 감사 말씀 드립니다.
bofxvii에 공개될 자작 bms와 차분 채보도 기대해주세요. - used_tami

first of all, thank you for downloading this sabun chart.
after this song and an one of the songs that will be released on bofxvii, i'm going to stop making sabun forever.
(if someone suggests my sabun chart on bms table, i'll contemplate it again)

and also want to take a break bms making for at least a year after bofxvii.
i'm not sure because of a lot of useless regrets about music...

my word ends here, and i made a sabun chart of an underated god music from bofu2015.
kireji's music is such an eargasm, another chart a mess though.
would be happy if you resonate with me.

thanks again to everyone who has played my bms and sabun.
stay tuned because my bms and sabun chart will be released on bofxvii. - used_tami