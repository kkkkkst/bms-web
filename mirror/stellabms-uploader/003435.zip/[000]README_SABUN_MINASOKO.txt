珊瑚郷 [ミナソコ]
Shimomura / obj:Mary_Sue bga:kelvin_kombinat
本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=328&event=142
推定レベル：★24-25?

[bms]the_secret_coral_regions.bms.unplaced 基準ズレ抜けなし。
よろしくお願いいたします。

2023/11/12
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)