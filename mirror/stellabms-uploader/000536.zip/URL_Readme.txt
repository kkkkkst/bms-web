曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=273&event=133

_7.差分用と比較してズレないことを確認しました。