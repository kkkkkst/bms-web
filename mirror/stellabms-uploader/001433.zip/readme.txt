Song IR : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=242&event=137

Chart Name : True End Stories
Difficult : sl11?

Chart Comment : SPA 기준 일그러짐 X

Personal Comment : 이번 명의는 작곡가님의 명의에 맞춰서 변형되어 있습니다.
H의 의미는 여러가지지만 한가지 확실한것은 G의 다음이 H라서 지어낸것은 맞습니다. (원래 nozomi의 N으로 하려고 했지만 사정상...)
차분 제목은 이번 BOFXVII 기간중에는 추가차분이 아닌이상 이곡이 마지막이 될거 같아 이러한 제목을 지었습니다.

스크래치 사출 직전의 12비트 동시치기가 일부 순화되어 있고 
후살직전의 그 끊어치기+트릴 구간이 12,67로 되어 있는것을 1,7로 통일했으며 (멜로디 구간이 절반씩 구간이 나누어져있는것은 그대로)
후살이 강하다는 점을 고려하여, 토탈치를 높였습니다.
