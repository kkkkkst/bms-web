SLAUGHTERTUNE -SPREE-
zen / obj: Mary_Sue

本体：https://drive.google.com/file/d/11vIvexNjrm-IWrjUhoBSnHedUNEirnjg/view?usp=share_link
推定レベル：★22ぐらい

slttn.bms基準ズレ抜けなし。

どうぞよろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2022/12/28