https://venue.bmssearch.net/letsbmsedit2/14

_yw_sotsugyou2000_7c.bmeと比較してBPM変更以外のズレなし
