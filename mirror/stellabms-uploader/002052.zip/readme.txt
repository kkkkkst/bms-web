本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=198&event=140

同梱SPAと比較してズレ抜け無し