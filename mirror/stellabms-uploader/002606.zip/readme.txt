there's no 一重乱打譜面 cause 同梱NORMAL perfect fit what I thought
Reiakiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii

原曲URL https://venue.bmssearch.net/bmstukuru2023/38
obj.Reiaki's twitter @AkihaReiaki