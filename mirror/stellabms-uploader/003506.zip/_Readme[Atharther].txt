ミライのオト
atily (feat. 夏色花梨) (movie : アカツキユウ)
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=42&event=140
推定レベル：sl3?

ズレ チェック : mirainooto_SP_01B.bms, mirainooto_SP_00.bms とのズレなし


26番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)