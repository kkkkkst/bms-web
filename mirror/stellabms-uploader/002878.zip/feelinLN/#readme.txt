stella uploaderの002521にアップロードしたfeelin' my new world [Straight], [Maniac]のおまけ穴抜き差分の単品です
元譜面はこっちから→https://stellabms.xyz/upload/2521

