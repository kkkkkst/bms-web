Rottfill [7K R-SHOCK]

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=49&event=140
推定レベル：★20? (st0ぐらい ?)
同梱Anotherベースです。

よろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/)
2022/12/01 