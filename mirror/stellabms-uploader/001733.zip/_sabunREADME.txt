本体URL：http://k-bms.com/party_pabat/party.jsp?board_num=22&num=39

Kafka_BASE.bmsとズレなし