---Song Information---

Title:燃ゆる白狐、匍う大蛇

Composer:Exsy

Song URL:https://venue.bmssearch.net/bmsshuin3/95

---Chart Information---

Chart Title:[W]

Obj:w

Difficulty:◆F地力（★9）

Judge Rank:EASY

Notes:1753(74LN)

Total:455

---Coment---

I'm in love with this entry from Shuin3.
Stick fight animations are so nostalgic for me, I didn't expect to see one made as a BMS BGA. The music flows so nicely with the animation.

I actually like the original charts for this song. The jacks are very fun to play. The only issue is that the original charts were a little unbalanced (the ending was too difficult and some parts of the chart feel empty).
When I tried to make a sabun for this song, I realized why. There are a lot of keysounds in this BMS that have not been sliced. As a result, there are many parts of the song with few keysounds. This makes it quite difficult to make a balanced insane chart for the song.

I originally wanted to make a LN chart, but I had to give up on the idea because many of the long keysounds were not sliced. The keysounds I had to work with were mostly drums. So I ended up just trying to make whatever chart I most felt like making, using the keysounds available to me.

Despite the keysound issues, this song is incredibly good material for making exciting charts. The music and BGA depict an intense battle against lots of enemies. What makes these battles exciting is all the multitasking involved - so many things are going on at the same time. That is the mood I tried to go for when making this chart.

Typically, a player goes for different "stances" for different types of patterns. For streams(乱打), a stable stance with static wrists and moving fingers is ideal. For chord(同時押し) patterns, the player locks their fingers together and focuses on wrist movements. For fast jacks(連打), a less stable, but more focused stance is used to bounce the fingers on the keys accurately. For LNs, the player forces the fingers to slow down and hold the keys instead of bouncing them off the keys. When there is a scratch note, the player briefly breaks stance to focus on the scratch note (especially for long scratch notes). It's not just about switching playstyles on a controller, it's about how a player mentally prepares for different patterns differently.

To capture this multitasking aspect, I tried to build a chart that makes the player switch stances lots of times. This means changing patterns often, trying to catch the player off guard whenever I could. This is why I think the music and the BGA fit together so well. The music changes frequently, with different instruments suddenly coming in at unexpected times. It feels natural to switch patterns when the instruments change.

My goal was to make a tricky and exciting chart, while at the same time keeping the chart fair and balanced (it is still a 地力 chart). I think of all of the charts in this event, this was the most fun to play for me.

Time spent: ~1 week

zure check: A.bms

---Other---

Website:https://wcko87.github.io/
Twitter:https://twitter.com/wcko87
自作譜面の難易度表:https://wcko87.github.io/bms-table/obj-w.html