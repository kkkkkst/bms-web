[Title]
CHMR [Dystopia]

[Difficulty]
st5

[URL]
https://www.dropbox.com/s/7e9a4w54yoz1zd4/%5BCRYSTAL%20TECHNOLOGY%5DCHMR.rar?dl=1

[Comment]
002248の修正版
物量差分(純粋16分乱打がメインの傾向のこと)
ズレやディレイ付加によるズレがあります。
アレンジ差分のため、すべてのズレや抜けは意図的です。
