A BEAUTIFUL SKY -OB STYLE- [DP]

SPのblack trainさんのGOD譜面で刺激を受けて作って見ました
ズレ抜けは全て意図的なものです