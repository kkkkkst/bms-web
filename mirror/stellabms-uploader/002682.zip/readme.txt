本体DL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=197&event=140

Fine Logic [polaris] ln17?
Fine Logic [Reality] ★10

vocal means I put empty keysound matching the vocal on the scratch lane
I haven't change the key lane at all for vocal sabun

obj.Reiaki's twitter @AkihaReiaki
