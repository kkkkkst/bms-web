---Song Information---

Title:SIMEDOKI

Composer:Qyubey feat. LyuU

Song URL:http://k-bms.com/party_pabat/party.jsp?board_num=20&num=27

---Chart Information---

Chart Title:[LN-W]

Obj:w

Difficulty:◆F1(◆8)? 

Judge Rank:EASY

Notes:513(350LN)

Total:240

---Coment---

One of my favorite songs from PABAT!2020, which was an amazing event all around.

This song lends itself very well to LN charts because it is slow and melody-focused, and because of how much sustain there is in the piano notes. The heavy ambient sounds also have a lot of prominence here, and they can be captured with long LNs.

I like how my LNs light up and darken the chart in a way that matches the BGA.

the chart ended up not having a lot of variety in patterning. There are really only four patterns in this chart, one pattern corresponding to one section of the song. The end result is a simple, slow and comfortable noodle chart.

Music-wise, this song was pretty straightforward and low bpm, so I took a lot less time to make this than usual.

Time spent: ~3 days

zure check: smdk_spa.bms

---Other---

Website:https://wcko87.github.io/
Twitter:https://twitter.com/wcko87
自作譜面の難易度表:https://wcko87.github.io/bms-table/obj-w.html