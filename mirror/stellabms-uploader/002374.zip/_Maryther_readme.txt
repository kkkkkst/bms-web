ぷばとと MARYTHER
ルナ・ヴィオーラ / obj: Mary_Sue

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=176&event=137
推定レベル：★15-★16?

Ploy_h.bms基準、BPMレーン以外ではズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/01/14