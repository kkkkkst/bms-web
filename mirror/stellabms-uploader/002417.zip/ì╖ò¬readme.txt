BOF2011楽曲と若干古い曲ですので、楽曲本体をお持ちでない方は以下からどうぞ(当差分同梱済み)

https://drive.google.com/file/d/17AUmZVq7bLbdGkhrDPABxKXgOEFI5wQv/view?usp=share_link