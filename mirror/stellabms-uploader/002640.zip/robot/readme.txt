song url : https://web.archive.org/web/20130226152217/http://big.freett.com/mekurumeku/morigasigeru_robot.zip

★? ロボット (terrific)
LR2でもbeatorajaでも作動するフルコン専用譜面の実験作
total値1, フルコン専用
beatorajaではフルコンランプ不可、ハードゲージでのみクリア可能です