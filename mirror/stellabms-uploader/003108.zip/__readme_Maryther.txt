藍の空 [MARYTHER]
by 白羽

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=38&event=139
推定レベル：★24
__normal.bms基準ズレ抜けなし。

要は藍とか会いとか哀とかあい☆こんぷりーととか
この世の全ての「アイ」のために
夏の終わりより愛を込めて

引っ越しで少し忙しいですがこの家で作る最後の差分だから頑張りました。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/08/31 