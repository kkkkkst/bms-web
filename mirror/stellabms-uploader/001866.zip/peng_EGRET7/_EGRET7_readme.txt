★20? 鵬程千世 [EGRET7]

修正版
ズレ修正・MAX-BPMでの表示対応(LR2)
Anzu BMS Diff Toolにてズレ抜け確認済み

本体URL	https://manbow.nothing.sh/event/event.cgi?action=More_def&event=133&num=485