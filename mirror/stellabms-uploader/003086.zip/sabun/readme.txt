_HM_blank.bmxと比較してズレなしです。
無音ノーツ多めです。

HAPPY Birthday 棟方愛海!!

(2023/08/01)