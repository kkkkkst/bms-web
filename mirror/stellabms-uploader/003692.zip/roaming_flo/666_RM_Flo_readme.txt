☆? Roaming melancholy -floccinaucinihilipilification-
ハード判定＋小ギミック　BPMFIXはSTARTBPMかMINBPM合わせで。


本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=85&event=127

※beatorajaでは同時発音数を増やさないと鳴らないキー音が一部存在します。
　プレイする際には設定画面のAudioタブから同時発音数を増やしてください