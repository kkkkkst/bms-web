[可愛いノヒミツ！]    ◆21-22     LN総合 
[リアリティー]        ★14-15     乱打

about misalignment problems:
1. I delayed a few kicks and snares to match long snare/kick rolls

2. The music is 3/4 bars earlier than the BGA
   I fix it by move all the keysound backward for 3/4 bars
   therefore it cannot pass the misalignment check
   if you move all keysounds forward for 3/4 bars it will pass
3. Why does no one ever realize the bga&music misaligned???

URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=338&event=88
Contact: twitter @AkihaReiaki