★25? Door Nock [Aberrant Delay]

意図的なズレあり

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=69&event=127
