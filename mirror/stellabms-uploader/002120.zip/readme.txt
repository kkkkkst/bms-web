本体:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=2&event=119
sl2の差分のミラーです