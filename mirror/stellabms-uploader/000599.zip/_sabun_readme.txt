すべてのズレとノーツが抜けているのは意図的です。

Randomize script by Sera (https://github.com/Seraphin-/bms-sabuns)