第三回BMS衆議院選 / Clowns Are Scary 2021 / hayato87b
本体： https://venue.bmssearch.net/bmsshuin3/7

_clowns_are_scary_2021_n.bmsと音ズレなし