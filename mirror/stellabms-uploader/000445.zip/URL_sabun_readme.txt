曲URL：https://dl.dropboxusercontent.com/sh/xrr3fvlhagzsmm2/AADrcgFDWT6axiabf5LwN9qia/bms/hurt%2Cscenery%2Cgroundrainbow.rar

追加音源を全て同じフォルダに入れてください。
Chords Practiceは強制的にS乱がかかります。

Inspired by hex (https://bms.hexlataia.xyz/)
Randomize script by Sera (https://github.com/Seraphin-/bms-sabuns)