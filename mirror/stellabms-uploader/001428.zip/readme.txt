Song IR : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=243&event=137

Chart Name : from now on

Difficult : sl6?

Chart Comment : no Zure

Personal Comment : 차분 제목은 곡 제목과 의미가 같습니다... 
처음에는 쉽게 만드려고 했으나, 동봉차분과 비슷해질거 같아서 살짝 막장스럽게 짰어요. 
마지막은 5년전까지 단위인정 8단 마지막(g로 시작하는 개버곡)이 생각날겁니다.
