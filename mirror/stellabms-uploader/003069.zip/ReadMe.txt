Song URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&event=140&num=297
no misalignment compared to SPA