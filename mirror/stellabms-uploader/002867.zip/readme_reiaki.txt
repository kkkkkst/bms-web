Song URL https://manbow.nothing.sh/event/event.cgi?action=More_def&num=286&event=140
obj.Reiaki's twitter @AkihaReiaki

this first one (no sabun name) is the first version of this series of sabun
I finish it at Dec 2022 for a sabun event called BigHan Cup seaon 12
here is the link https://www.bilibili.com/video/BV1Z14y1w7Mw/
it's not that good so I decide to not release it alone; it should serve as a bonus sabun
レモンとライム is a better version of the old one, gimmicks follow the same track but finer
there's also a no gimmick version of レモンとライム because I think the arrange is not bad

hispeed fix in start / average / main is ok (fix 152 bpm)
 
1666 notes is intentional

Thank you for playing!!!!!!