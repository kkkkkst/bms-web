★22? Sampling Satan [EX]

st2～3想定　TOTAL350　
追加音源あり

本体URL
https://roopdesign.net/post/34827532860/roop-bms-works-2004-2012

LR2IR
http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=322277