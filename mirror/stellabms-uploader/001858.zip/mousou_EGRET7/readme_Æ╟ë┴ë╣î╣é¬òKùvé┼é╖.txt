★24/st5? 妄想製造傘下 [EGRET7]

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=385&event=116


MIST様(@MIST_musicholic)作成の追加音源を使用しています。
以下URLより追加音源をDLして曲のフォルダに入れて下さい。

追加音源URL
https://drive.google.com/file/d/1Mdud6YDDUMfFHq5WPbimYrGl8ctb9W7u/view?usp=sharing


妄想製造傘下[SP FREEFALL](MIST様の差分)と比較してズレ抜けなし（Anzu BMS Diff Toolで確認）

