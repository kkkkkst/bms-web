dl link
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=24&event=69