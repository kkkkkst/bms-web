https://manbow.nothing.sh/event/event.cgi?action=More_def&event=133&num=7

_05_strange_m.bmsと比較してズレなし
