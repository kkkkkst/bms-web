Resist(BMS Refine) -blissful- (★17 / sl10)
music by CYLTIE.
bms : http://k-bms.com/party_pabat/party.jsp?board_num=21&num=6

-----------------------------------------------------------------------------------------------

CYLTIE.씨의 곡이야 저는 대부분 마음에 들지만
그 중에서도 'Bounce and the Ride'라는 곡이 정말 저어엉말 마음에 들어서
원래는 그 곡의 차분을 만들어보고자 했으나 파일 백업도 하지 않고 디스크 정리를 해버리는

결국 그렇게 1년이 지나 -blissful-이라는 타이틀은 이 곡에 붙게 되었습니다.

빨리 휴가 가고싶다,,, - tami