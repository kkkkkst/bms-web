★?(★5くらい？) Snow White -hallucination7-

LR2はBPMFIX OFF, beatorajaはSTARTBPMに合わせてください
緑数字は300程度を想定しています

※ズレ抜けチェック不可　追加音源も一緒に導入してください

INSANE, 0表記の-hallucination7:EX-は辛判定＋低total化したオマケ譜面です。
腕に覚えのある方は是非挑戦してみてください