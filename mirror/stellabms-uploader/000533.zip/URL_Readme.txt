曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=41&event=133

_00_ELIMINATOR_Master.bmsと比較してズレないことを確認しました。