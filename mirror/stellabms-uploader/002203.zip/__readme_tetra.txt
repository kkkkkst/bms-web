"Happy Hardcore"
Fly up to : the Sky [AETHER]
Yu^ta feat. みずにんじん obj.Tetra

★24下位（st4程度）想定

-------------------------------------

Anzu BMS Diff Toolを用いて元譜面（同梱Another譜面）とズレ・抜けがないことを確認済みです。
なお、音源はAnother音源を使用しています。
また元譜面にある停止およびソフランは削除しています（これに起因するズレはありません）。