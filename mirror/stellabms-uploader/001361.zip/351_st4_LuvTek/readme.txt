URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=351&event=137
Difficulty: st4?
파란색이니까 이지판정으로