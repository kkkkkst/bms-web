Song IR : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=374&event=137

Chart Name : Absolute 零

Difficult : st0?

Chart Comment : 모든 일그러짐은 딜레이 적용이며, 추가로 SPA 기준으로 #51에 중복 키음 적용이 하나 있습니다.

Personal Comment : 이곡은 예전의 Luca가 생각나서 고려했지만, 후반에 키음이 너무 없어서 결국 무키음을 너무 박고 딜레이도 이상하게 박았습니다..
차분 제목 읽는법은 앱솔루트 제로 그러니까... 절대영도라는 의미입니다.
