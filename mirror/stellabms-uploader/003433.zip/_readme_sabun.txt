Wildcard (7KEYS MARYTHER)
Y.W BGA: kotomi 
OBJ: Mary_Sue

for BOF:NT差分企画
本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=60&event=142
推定レベル：★24? 
_yw_wildcard_blankと比較するとズレ抜けなし

2023/10/19
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)