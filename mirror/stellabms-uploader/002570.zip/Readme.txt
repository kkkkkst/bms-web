[Title]
リクロスフェイト [Nuclear] / [Navigatoria] / [Nautilus] / [Noah]

[URL]
https://venue.bmssearch.net/bmstukuru2023/23

[Difficulty]
Nuclear : ★20 (st0)
Navigatoria : ★23 (st4)
Nautilus : ★24 (st5)
Noah : ★25 (st8)


[Comment]
同梱の「___normal.bms」と比較してズレ抜けなし。
本差分にはRandomizerを使用しております。
