�t�G�l�b�N by LisicA

[Foxy] Difficulty: st5? (����4)

Uses SPNormal file (01_fuenec_N.bms).

Somehow ended up becoming more of Nanami style rather than fsrs style. Frankensteiner of a chart... 

Song DL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=321&event=140
