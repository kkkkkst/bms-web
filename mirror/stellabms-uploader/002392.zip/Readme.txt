[Title]
time eclipse [parallel] / [paradox]

[URL]
https://drive.google.com/file/d/1u3XokH5PTiHhCkOe9gHMWoT3qljFpa8s/view

[Difficulty]
parallel : ★25 (st10)
paradox : ★27 (st12)

[Comment]
ディレイ差分
曲改変差分(微)のため、同梱譜面と比較すると物理的なズレや抜けがあります。
アレンジ差分のため、すべてのズレや抜けは意図的です。
