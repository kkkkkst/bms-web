---Song Information---

Title:urara

Composer:Ym1024

Song URL:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=13&event=134

---Chart Information---

Chart Title:[LN-W]

Obj:w

Difficulty:◆F1(◆6)? 

Judge Rank:EASY

Notes:852(567LN)

Total:296

---Coment---

For my final sabun for LN Festival, I wanted to make something easy and straightforward (◆F1).
urara is an honestly impressive song from 2HDBMS. Despite the final zip file being only 42KB, it has such a wonderful catchy melody, and is something I really enjoyed listening to. This makes it stand out in comparison to the other entries, many of which struggle to stay within the 1.44MB file size limit.

One nice thing about LN charts is that they tend to be very melody-focused (while rice charts tend to be drum-focused). While the abundance of keysound objects in urara allows for many kinds of charts, urara is a very melody-driven song, and it was nice that I was able to make this LN chart using almost only the melody layer of the BMS.
I think I was able to capture the spirit of the melody with this chart. It is comfortable to play and the long notes dance with the bouncy melody.

The second half of the song is mostly a repeat of the first half. This song is also only 1:36 long, so it ended up not taking a lot of time to make.

Time spent: ~4 days

zure check: urara_[7-B_Another].bme

---Other---

Website:https://wcko87.github.io/
Twitter:https://twitter.com/wcko87
自作譜面の難易度表:https://wcko87.github.io/bms-table/obj-w.html