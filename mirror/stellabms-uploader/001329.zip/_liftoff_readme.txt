!? uvea - 32082259297 [Liftoff]

�{��: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=100&event=137

had an idea for a light gimmick chart, unfortunately filesize went up by a lot lol
zure checks might go off due to the extreme bpms used

~ https://twitter.com/marie_qune