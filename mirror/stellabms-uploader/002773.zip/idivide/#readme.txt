☆6～7? I'll divide from me - 7straight
◆8? I'll divide from me - 7inverse◆

追加音源を一緒に入れてください　検出されるズレ抜けは仕様です
LN譜面はおまけです　穴抜き譜面