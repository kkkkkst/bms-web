曲URL：https://www.dropbox.com/s/y75i1xf7xdu1txc/88D.rar?dl=1

追加音源を全て同じフォルダに入れてください。