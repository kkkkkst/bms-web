SAKIGAKE by kas_0120 �~ ���؃V�B�^�P

[Tridecagon] Difficulty: st? (����3)

Uses SPNormal file (Sakigake_N.bms).
Shapes. Best enjoyed on non-random.

Total is rather low due to the size of the chords, and free recovery section from the pianos.

Song DL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=276&event=140def&num=276&event=140