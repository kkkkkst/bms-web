本体URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=89&event=123

差分用(拡張子を変えて使ってね).rmファイル基準でBGA定義を除いてズレないことを確認しました。