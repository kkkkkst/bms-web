---Song Information---

Title:3rDLucky

Composer:dawn-system / BGA: いくちおすてご

Song URL:https://event.yaruki0.net/BMSquare/impression/14

---Chart Information---

Chart Title:[W], [LN-W]

Obj:w

Difficulty:◆F地力（★7）, ◆F2-3(◆12)?

Judge Rank:EASY, EASY

Notes:2400(82LN), 1492(688LN)

Total:484, 409

---Coment---

[W]
I'm really happy to see dawn system making BMS again. I actually started making this sabun before the LN festival event was announced.
This song is fast and exciting, and I think it has a lot of potential for fun charts. That's why I decided to make a 地力 and LN chart for it.

This was a difficult chart to make.
When I make charts, I try to match the intensity of the pattern to the intensity of that part of the song. However, this song has many intense parts with few keysounds, and calm parts with many keysounds.
In fact, much of this song's keysounds come from a few short bursts of arpeggio notes during otherwise calm sections. Because most of the ANOTHER chart's difficulty comes from these short arpeggio bursts, it makes the chart feel a little imbalanced.
When I made the chart, I tried to be careful not to use too many keysounds from these arpeggio bursts, while trying my best to stretch the difficulty of the rest of the chart to match the arpeggio bursts. 

Another difficulty is that this song is very melody-focused. So to give the player the feel of playing the song, I need the patterns to emphasize the melody. But melodies are usually simple with few notes. It is difficult to make difficult patterns by charting just the melody keysounds, and if I use too many non-melody notes, the melody is de-emphasized.
Som tools I use to emphasize melody:
1. Long Notes (LNs are highly visible, and can also make tricky patterns with few notes)
2. Big chords(同時押し)
3. Jacks(連打) or Gachi (making a note part of a jack/gachi pattern increases player focus on that note)

Of course, each approach has its drawbacks. Too much of (1) turns the chart into a LN chart. Using (2) means I may have to add blank keysounds make the chords larger. Using (3) is usually only appropriate when the melody has two of the same note in a row.

Note: My rule is that blank keysounds are only allowed for making chords larger. I will not use blank keysounds for any other purpose.

In summary, I wanted to ensure that:
1. The chart difficulty is relatively balanced
2. The intense parts of the songs are matched by intense patterns and calm parts of the song are matched by comfortable patterns
3. The melody of the song is properly emphasized
4. There is enough variety in the song patterns
I took a lot of pattern rewrites and playtesting to achieve these. I think I am satisfied with the final result.

Total time spent: around 2 weeks?

Oh, also I did this weird time signature trick at the start of the song, so that the 50% bpm intro actually moves at 75% scroll speed. I think soflan is fun between 75% and 150% scroll speed (not 50%/200%).


[LN-W]
This chart was much easier to make than [W].

As I said before, this song is quite melody-focused. And LNs are also very good for emphasizing melody. So I think I had a lot more freedom to make various interesting patterns in this chart.

As before, I had to be careful not to make the arpeggio bursts too difficult compared to the rest of the chart. There are also many intense drum sections in the song. I have to emphasize them in the chart, but drums are not good for LN patterns, so I had to be a little careful there.

When making this chart, I had to constantly remind myself to focus on the melody.
And as always, lots of playtesting and iterating. I think this chart turned out pretty fun. I really enjoy playing it.

Total time spent: a little less than 1 week

I didn't do the 75% scroll speed trick for this chart, because I think LN pattern difficulty is less affected by scroll speed.

zure check: 3rDLucky_template.3rD

---Other---

Website:https://wcko87.github.io/
Twitter:https://twitter.com/wcko87
自作譜面の難易度表:https://wcko87.github.io/bms-table/obj-w.html