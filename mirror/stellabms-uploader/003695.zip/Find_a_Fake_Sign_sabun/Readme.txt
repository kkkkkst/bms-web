

---------------------------------

Find a Fake Sign

[Fake LongNotes] ln10?
[Spot the Difference] fr0 (☆?)

---------------------------------

[Fake LongNotes] ※ギミック譜面です

一応beatoraja推奨ですがLR2でも動きます
LN難易度表はあまり触ってないので一応これくらいかなというのを付けてます

[Spot the Difference]

間違い探しです
間違いを見つけたらそのレーンだけ押し続けてその他はすぐ離してください
初めてRANDOM定義を使用したのでもしかしたらどこかでミスがあるかも

=================================

Music: Suzuka
obj: くろ

Base BMS URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=20&event=140

=================================

Update:
2024-2-17 20:20 [Spot the Difference] LR2で地雷が残ってしまいノーツが押せなくなるのを修正
