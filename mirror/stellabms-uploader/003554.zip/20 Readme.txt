あAアぁ亜aァ
ああああ(ルゼ)
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=43&event=60
推定レベル：★21? / St0~1?

ズレ チェック : 03_yusha_spa_bga.bme とのズレなし


29番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)