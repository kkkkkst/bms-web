★9/sl5? Colored [rainbow]

本体URL
http://www.yamajet.com/bms/data/yamajet_colored_BGALQ.rar

同梱7keys譜面と比較してズレ抜けなし(Anzu BMS DIff Toolで確認)