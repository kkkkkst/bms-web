差分の差分作成用に[HEARTLESS]のBass譜面を同梱、作成自由。

