��25 r - �N���m�o�C�U�[ [Hyper-V]

�{�́Fhttps://manbow.nothing.sh/event/event.cgi?action=More_def&num=88&event=132
zure check: _AnotherVisor.bms

obj. marie vs AXION

~ https://twitter.com/marie_qune
~ https://twitter.com/dialgadu77