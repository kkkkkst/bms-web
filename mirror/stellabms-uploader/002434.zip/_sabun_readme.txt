汎凡なる異彩[凡rtistic]
Trantech (obj: Mary_Sue)

本体リンク：https://venue.bmssearch.net/artisticbms/7
推定レベル：★21-22?

同梱_7N.bms基準ズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/01/27