本体リンク：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=380&event=137
推定レベル：★13-15?
コメント：ロングノーツ、ディレイ、皿などの要素をたっぷり入れました。

同梱Lost of Fire MORE DROP MIX.bms基準、全てのズレ抜けはキー音切れのせいで出たものです。