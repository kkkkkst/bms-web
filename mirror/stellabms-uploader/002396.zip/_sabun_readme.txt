Ether dive -Overcast-
Umber Green / obj: Mary_Sue

本体リンク：https://drive.google.com/file/d/1mOEf7rIxI-xUK_yYJtgVgs_Lt1nRAGc1/view?usp=share_link
推定レベル：★2-3?
umber-green_ether-dive.bms基準ズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/01/20