FakeAltar 0.6[TERATOID] / FakeAltar 0.6[TERATOMA]

本体リンク：https://pupuly.nekokan.dyndns.info/bms/v/236
推定レベル：★23 (TERATOID) / ★24 (TERATOMA)
_7kHyper.bms基準ズレ抜けなし。

よろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/03/15
