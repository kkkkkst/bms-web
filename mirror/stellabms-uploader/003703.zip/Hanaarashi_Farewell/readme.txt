st0? 花嵐、空に溶けて [Farewell] 
本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=25&event=142

手動ディレイのため、厳密なズレ抜けチェック不可
同梱未配置ファイル(_default.b)から作成しており、これとbms diff toolで比較するとズレ抜けが出ないことを確認しています(ディレイ部以外のズレ抜けは無し)