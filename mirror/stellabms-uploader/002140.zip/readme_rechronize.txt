차분명 : ABNORMAL

테스트 : sl1?

비교 : SPA 기준 중복음 제외 즈레 X

원곡 URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=208&event=21

코멘트 : 아주 오랜만에 발광 입문 채보를 만들었으며, 대놓고 ANOTHER와 INSANE의 중간에 낄라고 만든 차분입니다. 