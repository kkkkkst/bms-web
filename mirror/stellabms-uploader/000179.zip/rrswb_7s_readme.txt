Ra-vine remix "shell with blue" by ridis
1/22/2002 ~~~~~~~~~~~~~ N/H/A/I 2/6/9/12
[======================================]
object by sera for BCEG 1998to2020 event
ha1, ha2, ha3, sweep were sliced by me
(#WAV25, #WAV26, #WAV27, #WAV2A)
I=☆12=~★2=~sl1

base BMS mirror: https://bit.ly/3anOfvn

N/H/A are a bit low on the note count
side but make up for it with a bit of
rhythmic difficulty and jacks in the A.
The I is a bit on the standard side with
mostly chordstream with melody emphasis,
light jacks and a bit of LN/scratch.

Rai/ridis/guna has always been one of my
favorite BMS artists, before I even
really knew much about BMS music itself.
He has made many songs that have had no
sabuns made (or are even seemingly lost
to time). This is one of my favorites
that I thought needed a sabun too. To be
honest, a lot of their work pre-2002
under the Rai alias is not that great,
but if you ask me all the songs under
the ridis alias are worth listening to!

This is my first time making low level
charts, and it's definitely been a while
since I've played stuff at that level,
but I am happy with how they turned out.

I also made a script for this that let
me chart the chordstream with ZZ objects
and automatically replace them with
sounds (if possible). It will be on my
GitHub sometime in future. Still, many
remain empty because I used multiple
notes for the lead in A/I especially. :(

Special thx to fk for helping me obtain
this song in the first place, and to |\|
for charting something for whisper :^)

 aquaseeds (guna) http://aquaseeds.net/ 
       https://seraphin.xyz/sabun       
[======================================]
