st3の差分のミラーです
本体https://manbow.nothing.sh/event/event.cgi?action=More_def&num=17&event=127