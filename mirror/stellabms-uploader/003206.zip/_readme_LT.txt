URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=41&event=142
Difficulty: sl11 (★18)
No misalignments compared to _Gasoline_N.bms.

BOF:NT差分企画: https://darksabun.github.io/event/bofnt/