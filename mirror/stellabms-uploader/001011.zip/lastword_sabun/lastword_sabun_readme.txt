[niconicore]ラストワード / itaojirou

差分2つありますが譜面はどちらも同じです

_lastword_f_voice_on.bms
→ラストワード [Deflation world+]
※BGA,ボイス有り

_lastword_f.bms
→ラストワード [Deflation world]
※BGA,ボイス削除
