#TITLE キラメキラリ [やよい軒]
#ARTIST 高槻やよい/obj:YAN*TS

お久しぶりです。YAN*TSです。最近BMSのモチベが回復してきたので数年ぶりに差分作り復帰してみました
ctcさんの差分の追加音源も必要です↓
http://ctconnected.blog.fc2.com/blog-category-1.html
おま環なのかコーデックに問題があるのか分かりませんが「momo.ogg」だけなぜかbeatorajaで再生できないのでエンコし直してます。上書きさせてください

Discord：　YAN*TS#8022
Twitter：　@yantaisa11