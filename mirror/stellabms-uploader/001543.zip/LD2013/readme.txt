Have you been already boosted? Not yet? Oh my god.
All you have to do first is get vaccinated. You should, I think.

If you have some questions, please check below.
https://www.who.int/emergencies/diseases/novel-coronavirus-2019

If you want to search more detail, please check below.
https://pubmed.ncbi.nlm.nih.gov/?term=COVID-19
https://www.uptodate.com/contents/covid-19-epidemiology-virology-and-prevention

Have a good life.

