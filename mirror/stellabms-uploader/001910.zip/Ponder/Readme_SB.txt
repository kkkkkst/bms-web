★24/SB9?  Ponder [Scramble]
★14/SB5?  Ponder [Turn]

paraneumann obj:EGRET.


皿譜面でございます。Scramble難易度表向けの高難易度譜面が少なかったので自作してみました

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=225&event=133

AnzuBMSDiffにてズレ抜けなし確認済み