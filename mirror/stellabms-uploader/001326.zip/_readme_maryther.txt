本体リンク：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=227&event=137
推定レベル：★23-24? 
コメント：今日（2021/11/11）、コロナワクチンを接種するのでもしかするとこれが私の生涯最後の差分になるかもしれません（泣）

https://darksabun.github.io/Mary_Sue/