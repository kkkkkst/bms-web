�{�́Fhttps://manbow.nothing.sh/event/event.cgi?action=More_def&num=320&event=127

zure check: 7K_MX.bms

~ https://twitter.com/marie_qune