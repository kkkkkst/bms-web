[TITLE / ARTIST]
Galaxy in Toybox / 梅干茶漬け (movie : むらたむうた) 様

[本体URL]
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=118&event=96

[推定難易度]
★★5？(st7？)

[この差分について]
本差分はアレンジ差分です。すべてのズレや抜けは意図されたものです。