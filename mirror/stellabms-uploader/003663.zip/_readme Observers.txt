Orbitalgazer

qfeileadh 

obj.Atharnal
ズレ チェック : 04_orbitalgazer_SPA.bms とのズレなし

本体 : https://k-bms.com/party_pabat/party.jsp?board_num=23&num=38&order=reg&odtype=a
推定レベル：sl4, ★6~7?


個人的にqfeileadhの曲が好きですが、
bof:nt企画でほとんど制作して提出したので、
他のイベントであるpabatから選曲しました。

よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)