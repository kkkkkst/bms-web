URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=171&event=137

Difficulty: st3?
Comment: 一部のキー音を切ったため、意図的なキー音抜けがあります