��24 nitro - [line:��] [HYPERLIMINAL]

�{�́Fhttps://dl.dropboxusercontent.com/s/1wbit5p08wqyxmm/%5Bline%EF%BC%9Atheta%5D%20%28by%20nitro%29.rar
����Fhttps://youtu.be/c0htd0d5eQA

I spent a lot of time making and polishing this chart. It was
definitely designed with nonran in mind, so please play it
without random first if you want to experience it properly.
I think it's very fun! I hope you like it.

zure check: _line-theta_4_nitro.bme

~ https://twitter.com/marie_qune