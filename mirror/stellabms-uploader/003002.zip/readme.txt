https://manbow.nothing.sh/event/event.cgi?action=More_def&num=36&event=129

_eye_normal.bmsと比較してズレなし
#066小節以降は意図的にカット
