�{��:
http://web.archive.org/web/20120108070726/http://www7b.biglobe.ne.jp/~ssbossmix/sakuzyo_Neurotoxin_ogg.zip