本体URL：https://web.archive.org/web/20060519063240/http://migikacha.s80.xrea.com/bms/yo_gunjo_utage.zip

すべてのズレとノーツが抜けているのは意図的です。
キー音を追加で再配置しながら原曲と変わったので新しく未配置ファイルを作成しました。 差分製作にご使用ください。