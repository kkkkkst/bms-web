いつものアップローダーが落ちてたのでミラーとしてどうぞ
内容はsl12 dy0のものと同じです
もちろんすべてのキー音ズレは意図的です
本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=273&event=96