Song IR : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=85&event=137

Chart Name : LUNATIC , IMMORTAL

Difficult : sl5?, sl12?

Chart Comment : X

Personal Comment : 작년의 그 스크래치 곡과 유사하게 스크래치 음을 전부 키 배치로 변경한 패턴입니다.
(12/10) IMMORTAL 추가, LUNATIC 패턴 중간 부분 수정