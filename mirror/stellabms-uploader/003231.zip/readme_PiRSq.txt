dropmain_000_PiRSq000.wav
dropmain_000_PiRSq001.wav
dropmain_000_PiRSq002.wav
dropmain_001_PiRSq000.wav
dropmain_001_PiRSq001.wav
dropmain_001_PiRSq002.wav
dropmain_006_PiRSq000.wav
dropmain_006_PiRSq001.wav
dropmain_006_PiRSq002.wav

추가 파일을 차분과 같은 폴더에 넣어주세요.




