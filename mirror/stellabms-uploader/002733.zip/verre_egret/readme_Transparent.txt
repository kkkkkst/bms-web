☆12/SB3? Verre [Transparent] 
TAK / ke (obj:EGRET.)

HARD判定　TOTAL120
一部曲改変あり
追加音源あり

本体URL
https://onedrive.live.com/?authkey=%21ANyZD9QeOV1qq4k&cid=3078649C19F9CDD6&id=3078649C19F9CDD6%21898&parId=3078649C19F9CDD6%21105&action=locate
