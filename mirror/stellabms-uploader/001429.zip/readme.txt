Song IR : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=189&event=137

Chart Name : Haven't you heard?, I'm the crazy bitch around here, Alternative Break

Difficult : st2?, st6? st9?

Chart Comment : 모든 즈레는 전부 딜레이 추가음 (st2,st6,st9 전부 해당)

Personal Comment : 

haven't you heard? : I'm The Crazy bitch around here의 하위호환이자 st2가 짜고 싶어서 만든 패턴
I'm the crazy bitch around here : 작년의 그 패턴 개선판
Alternative Break : 싱귤러리티 입문

모든 패턴 전부 토탈치가 765이며, 작곡가님이 좋아하는 게임의 제작회사에서 따왔습니다.

st2,st6급 테스트에 협력해주신 七海님,LuvTek님,qtp13님,extra님께 감사드립니다.