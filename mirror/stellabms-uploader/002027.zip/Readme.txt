[Introduction]
「http://gnqg.rosx.net/upload/」
上記アップローダーで、06145にアップロードしたものと同一

[Title]
Streiflicht [Starlight]

[Event URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=424&event=133

[Difficulty]
★★6(st10)

[Comment]
連打とズレ物量
アレンジ差分のため、ディレイ等の付加によるズレがあります。
AnzuBMSDiff toolで同梱の「_Streiflicht_7normal.bms」と比較して
意図しないズレがないことを確認済。
