本体 http://electro-planet.net/loveplus/aihana.html

ZURE = INTENTIONAL (ON PURPOSE)