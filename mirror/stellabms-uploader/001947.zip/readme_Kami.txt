I think it's very sad that such a wonderful song is heavily overlooked, so I wanted to create a sabun for it.
I think one of the reasons why it's so underrated is that it was made for a +18 event and has NSFW graphics, so I decided to remedy that as well and gave the girl a bra!
I hope she's feeling a bit warmer now :)