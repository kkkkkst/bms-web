Orange jam reqiem for 2jankies (MissingNo.)
dust.c / obj: Mary_Sue
from 第六回自称無名BMS作家が物申す！

本体リンク：https://mega.nz/file/DkckURDK#DekrvDmvPKa9cCfvowwWGuxbwL0q8OnUyh40GT6mpKs
推定レベル：★24?
同梱の7ch.bme基準BPM関連二つのズレ・抜けがあります。それ以外はズレ抜けなし。

よろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/02/09