Song IR : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=189&event=137

Chart Name : I'm the crazy bitch around here

Difficult : st7?

Chart Comment : 모든 일그러짐은 딜레이 적용입니다.

Personal Comment : 이걸로 3번째 딜레이 패턴이며, 본 명의로 짜는 딜레이는 이번이 처음입니다. 잘 부탁드립니다.

검토 과정에서 패턴이 변경될수 있음을 알려드립니다.

