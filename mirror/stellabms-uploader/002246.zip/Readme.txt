[Title]
GIGAHERTZ [Farthest]

[Difficulty]
st12

[Event URL]
http://k-bms.com/party_pabat/party2016.jsp?board_num=16&num=1&order=reg&odtype=a

[BMS URL]
https://drive.google.com/file/d/1yEl1mockJcCisDKDXsQpb9qZVrWy747x/view?usp=share_link


[Comment]
物量差分(純粋16分乱打がメインの傾向のこと)
_gigahertz_O.bmeを軸に(？)作成しました。
ディレイ付加によるズレがあります。
アレンジ差分のため、すべてのズレや抜けは意図的です。
