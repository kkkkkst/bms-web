---Song Information---

Title:calming patterns to soothe the mind

Composer:Lollipop, with respect to Alexandre de la Fontaine

Song URL:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=40&event=135

---Chart Information---

Chart Title:[LN-W]

Obj:w

Difficulty:◆F3(◆14)? 

Judge Rank:EASY

Notes:2587(1034LN)

Total:522

---Coment---

158bpm? This plays more like a 316bpm song.
I love this entry. It's different from lollipop's usual slower work and it's definitely a song you can call "insane piano". 

The original charts for this song are a bit meme-y, so I wanted to see if I could make something proper. Keysound-wise, this is amazing. There is so much that can be used. There is one issue that makes charting this difficult though, and that is the ending stretch.

The song ends with a very long polyrhythm section, which honestly can be quite tricky to chart. Most sensible patterns for a section like this would involve a lot of repetition, the kind of pattern where you either trip and instantly lose all your gauge, or don't trip and slowly recover from 0% all the way up to 100% because the section is so long.
Essentially, the rest of the chart wouldn't matter. You pass or fail depending on whether you hit the polyrhythm section without messing up.

In addition, the song has a long fadeout, which can give a lot of free recovery.

When making this chart, the very first section I worked on was the polyrhythm section. I had to come up with something that didn't instantly drop you to 0% if you mess up and give you a 100% recovery otherwise. If I couldn't find such a pattern, I wouldn't be able to chart this.

I couldn't really think of something good without LNs, so this ended up being a LN chart. I ended up not using the polyrhythms, instead focusing on the main chords while mixing in long notes for difficulty. I think I've managed to make a fitting pattern where you have to fight to keep your gauge up, while not giving you a full gauge recovery.

I used a noodle pattern for the fadeout because that makes the ending still tricky to play, and makes the chords look big while keeping the actual number of notes used low (so there is less free recovery).

The rest of the song gives me a lot more flexibility in the charting. The high note density and "high bpm" makes it difficult to go for long noodle patterns, without making the chart way too difficult for me to play. Thus the chart utilizes mostly rice and short LNs. The short LNs emphasize the steady marching progressions on the left hand throughout the song, while rice is used for the accompanying insane melodies on the right hand. 

Structurally, the song is divided into eleven independent sections, with each section having 8+8 measures of a different repeating melody. The last two sections are the polyrhythm sections, leaving us with nine remaining sections. Making this chart is basically thinking of a unique repeating pattern for each of these sections. There are some brief transitions in the sections which allowed me to throw a curveball in some of the patterns to make them more exciting.

The ninth section (just before the polyrhythms) was the most tricky to chart, because it took quite a bit of time to figure out the structure of the melody which initially sounds like a complete mess.

One trick I use for charting is to make the sections which I have ideas for first, instead of charting from start to end. I think forcing myself to chart a section I currently don't have inspiration for will lead to a boring pattern. This chart was made completely out of order. Charting out of order also prevents the chart from getting increasingly more difficult as you progress (especially for long songs like this).

After that, as usual, plenty of playtesting and adjusting the patterns to ensure that the difficulty is roughly balanced and the patterns are fun to hit. This chart took a long time to make, simply because of how long the song is (230 measures).

Time spent: ~2 weeks

Why do I write so much? Maybe it's just my tendency to spend a lot of time reflecting on every action I take? I could write so much more, but I'm trying to control myself here...

zure check: another.bms

---Other---

Website:https://wcko87.github.io/
Twitter:https://twitter.com/wcko87
自作譜面の難易度表:https://wcko87.github.io/bms-table/obj-w.html