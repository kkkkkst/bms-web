曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=451&event=110

fakeover_bgm.xxxと比べてズレないことを確認しました。