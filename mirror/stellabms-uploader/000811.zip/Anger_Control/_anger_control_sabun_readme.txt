本体URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=457&event=133

ogg版の場合はsound_oggフォルダのファイルを、wav版の場合はsound_wavフォルダにあるファイルをすべてbmsファイルと同じフォルダに入れてください。