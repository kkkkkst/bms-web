��12 Ark-Z feat. ���Ȃ���� - I'M HERE NOW [Sink Down a Frozen Atlantis]

�{��: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=186&event=123

zure check: IM_HERE_NOW[SP ANOTHER].bms

current hyperfixation: vocal trance
love u all <3

~ https://twitter.com/marie_qune