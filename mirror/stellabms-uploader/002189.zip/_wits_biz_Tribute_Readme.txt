Wit's Biz [Tribute]
예상 레벨 : sl7~8
유형 : 난타, 즈레, 12비트 끊어치기
토탈값 : 475

Comment : Remilegi of Fighters 2022에 출전한 차분입니다. BMS 차분을 난생 처음 찍어보는거라 많이 어색할 수 있지만 그래도 많이 플레이해주시면 감사하겠습니다.

the_end.ogg 키음이 the_end_cut.ogg로 대체되었으니 추가 키음을 해당 곡 폴더에 같이 넣어주시길 바랍니다.


Wit's Biz [Tribute]
予想レベル : sl7~8
タグ : 乱打, ズレ, 12分 ガチ押し
トータル : 475

作成者コメント : RemilegiofFighters2022に出場した差分です。 BMSの差分を生まれて初めて撮るのでぎこちないかもしれませんが、たくさんプレイしてくださればと思います。。

the_end.oggキー音がthe_end_cut.oggに置き換えられましたので、追加キー音を該当曲フォルダに一緒に入れてください。

Translate : Naver Papago