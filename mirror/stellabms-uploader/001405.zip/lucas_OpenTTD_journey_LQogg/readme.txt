Original song from OpenMSX. (https://github.com/OpenTTD/OpenMSX)
license is GPL v2. (see license.txt)