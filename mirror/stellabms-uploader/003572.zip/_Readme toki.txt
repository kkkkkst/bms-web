Dream of Memories
Abel & Inu (movie : VARD & marierie)
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=52&event=137
推定レベル：☆12 / sl0

ズレ チェック : _DOM_spa.bms とのズレなし


30番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)