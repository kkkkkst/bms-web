DP★8 Heterochromia Iridis [eyes]

BMS URL
http://leafbms.web.fc2.com/song.html

LR2IR
http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=310565

No Misalignment (_A7.bms)