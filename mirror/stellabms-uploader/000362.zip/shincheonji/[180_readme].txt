psychedelic trancecore / shincheonji [180] - the kristian council of chorea (a.k.a. used_tami)
(original bms by sctl : http://k-bms.com/party_pabat/party.jsp?board_num=20&num=66)

※ installation
  just unzip and move the files to the original bms folder. no files are overwritten.
  그저 압축 풀고 파일들을 원본 bms 폴더로 이동시키세요. 덮어쓰기되는 파일은 없습니다.
※ bpm : 150 → 180
※ new 3 graphics
  #stagefile : scj_eyecatch.jpg → 180_eyecatch.jpg
  #banner : scj_banner.png → 180_banner.png
  #bmp01 : scj_bga.mpg → 180_bgi.bmp
※ new 12 keysounds time-stretched by bpm


this sabun is not for expressing opinions about a particular person, religion, or group.
이 차분은 특정 인물, 종교 및 단체에 대한 의견을 표명하기 위한 차분이 아닙니다.

reliable, 180bpm!
든든하다, 180bpm!