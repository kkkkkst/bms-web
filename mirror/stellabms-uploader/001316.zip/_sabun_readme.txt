本体URL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=302&event=137

14PhilX_SPA.bmsと比較してズレないことを確認しました。