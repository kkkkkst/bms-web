ポーチュラカ [めありーざー] // ポーチュラカ [めありーざーぷらす]
作曲・絵: kotomi / 編曲: Y.W / 譜面: Mary_Sue

本体：https://venue.bmssearch.net/hanadayori/4
推定レベル：★14 [めありーざー] / ★23 [めありーざーぷらす]
_kotomi_yw_portulaca_7a.bml 基準ズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/02/20