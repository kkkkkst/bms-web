NOTES 2000
TOTAL 400

BMS_DL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=1&event=130