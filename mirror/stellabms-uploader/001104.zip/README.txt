代替本体/Secondary URL: https://www.mediafire.com/file/6fk6tybshd8buyl/CROSSSOUL.zip/file



(Eng)
Note:
7SE map is based off of m4cho's sabun, and uses an mildly edited version of the ending.
http://onmacodayo.web.fc2.com/0117/CS_ERROR.bms