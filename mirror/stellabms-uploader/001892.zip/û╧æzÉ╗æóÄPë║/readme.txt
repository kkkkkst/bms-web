BGMが長すぎてIR登録出来ませんでしたので、分割しました。

BGM1 → BGM_n1, BGM_n2, BGM_n3
BGM2 → BGM_n4, BGM_n5, BGM_n6

追加音源は以下からDLしてください
https://ux.getuploader.com/numuther/download/102