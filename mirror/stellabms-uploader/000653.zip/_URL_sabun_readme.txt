本体URL：https://venue.bmssearch.net/bmsshuin3/75

Fresco.bmsと比較してズレないことを確認しました。
ボリュームが小さいのでBVlmで一括400%db処理することをおすすめします。