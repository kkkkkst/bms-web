Song IR : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=85&event=137

Chart Name : SP CATACLYSM

Difficult : st5?

Chart Comment : 키음 02에 나온 일그러짐 표기는 무키음이어서 실제로 영향이 없으며, 마지막 18번 키음을 64비트로 늘린것빼고는 음의 변화 X

Personal Comment : 중살부분 너프시키고 뒤에 조금더 상향시켜서 밸런스를 맞추었습니다.