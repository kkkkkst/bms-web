本体→https://web.archive.org/web/20140111134046/http://grooverise.sakura.ne.jp/azu_fin.rar

末尾に無音の不可視ノーツを足してます(oraja用)