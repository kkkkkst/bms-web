Song URL : https://drive.google.com/file/d/1p1jgDsJdYgSdfbg_dh78GKbaW482FFYs/view
No Misalignment compared to WW_BASE.bms