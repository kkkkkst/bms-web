本体URL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=224&event=137

tonakai_no_mukuro_SPA.bmsと比較してズレないことを確認しました。