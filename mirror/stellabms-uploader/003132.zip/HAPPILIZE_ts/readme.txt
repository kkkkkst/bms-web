同時押しの一部に無音ノーツ使用
同梱beginnerとズレなしチェック済み(無音ノーツ除く)
同梱譜面において81小節目に同音ノーツが存在したものをそのままにしているためduplicate checkでエラーが出ます
本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=171&event=133