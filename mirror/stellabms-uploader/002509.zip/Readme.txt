[AnzuBMSDiff]

Andromeda_SPA와 비교하였을 때
[006] P3(b_strings_stac_v70l8o6cp.wav) : SPA에선 P3이 삭제되어 있으나 다른 Sabun(SPN, SPH, default)에는 포함되어 있어서 삭제하지 않았습니다.
읽어주셔서 감사합니다.

Andromda_SPAと比較したとき
[006] P3(b_strings_stac_v70l8o6cp.wav）: SPAではP3が削除されていますが、他のSabun(SPN、SPH、default)には含まれているため削除していません。
お読み頂きましてありがとうございます.

When compared to Andromeda_SPA
[006] P3(b_strings_stac_v70l8o6cp.wav) : P3 was deleted in SPA, but it was included in other Sabuns (SPN, SPH, default) and was not deleted.
thank you for reading.


I was helped by papago translate.