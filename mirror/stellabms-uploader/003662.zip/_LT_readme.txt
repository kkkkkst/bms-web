URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=404&event=142


Based on Scream_Our_Instinct!!(Normal).bms with additional keysounds.
Deleted duplicated keysounds and modified the timing of #WAVLB in measure #055.


"Scream_Our_Instinct!!(Normal).bms"に基づいて、追加音原を使用しました。
重なるキー音オブジェクトを削除し、#055小節の#WAVLBのタイミングを調整しました。




