Fate Machine(Fatal)
YATA / obj: Mary_Sue

本体：https://pupuly.nekokan.dyndns.info/bms/v/17
推定レベル：★15-16?
FateMachine(Another).bmsとズレ抜けなし。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/12/14