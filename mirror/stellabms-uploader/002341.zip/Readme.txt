[Instruction]
002294の修正版

[Title]
First Creation [Galaxy]

[Difficulty]
st11

[URL]
https://www.dropbox.com/s/fjccjz390i2vfbp/First%20Creation.rar?dl=1

[Comment]
連打差分
AnzuBMSDiffで同梱の03_First Creation_A.bmsと比較してズレ抜けなし。
