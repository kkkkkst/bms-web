[Title]
Bubbling Fairies (2020 BMS edit) [Diamond Blizzard]

[Event URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=31&event=129

[Difficulty]
★23(st4)

[Contents]
ズレ連打
同梱の「_BublingFaires_temp.bms」と比較して
意図しないズレがないことを確認済。

[Breakdown]
もにもに : 前半パート担当
fuko : 後半パート担当