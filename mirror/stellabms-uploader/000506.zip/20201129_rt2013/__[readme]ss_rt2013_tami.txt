BOFFT2013 (helemaal niet)

sabun author : tami
difficuly : ★20 / st0
bms link : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=5&event=133
comment : no comment

원본 bms에 키음이 중복 배치(duplicated)된 부분이 있지만 그대로 뒀습니다