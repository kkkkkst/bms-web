12개의 노트 중복 에러가 검출되지만 키음 엇갈림이나 누락은 없습니다.
(_ECKESACHS_No_pattern 끼리 비교해도 에러 발생)

감사합니다.

DR : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=24&event=140