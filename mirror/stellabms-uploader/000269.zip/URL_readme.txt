曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=268&event=127

_A.bmeと比べてズレないことを確認しました。