★14(sl8) Lost World [EX7]
譜面傾向：物量、乱打、同時押し、終盤難

1005様によるBGA差分を適用した差分です。下記のURLからBGAを別途ダウンロードしてください

*ズレ抜けについて
BGA差分である1005_lost1.bmeと比較して意図的なものを除くズレ抜け無し。
#015～016, #031～032, #047～048, #063～064, #079～#080で検出されるズレはすべて意図的なものです

Song URL : https://web.archive.org/web/20061125103338/http://tobitaro.hp.infoseek.co.jp/bms/lost.lzh
BGA URL : https://web.archive.org/web/20060126103515/www.geocities.co.jp/Playtown-Knight/5996/1005_lost_bga.lzh