Ladies' Tresses [SILLY]
樟 / obj: Mary_Sue

本体リンク：https://drive.google.com/file/d/1VuupAPxjactYbTx9s2Y4fdPKE2b74Awe/view?usp=share_link
推定レベル：★15-16?
同梱のladies_tresses.bms基準ズレ抜けなし。

よろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/03/04