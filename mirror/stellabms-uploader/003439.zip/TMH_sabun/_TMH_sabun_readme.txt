本体URL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=513&event=142

追加音源を全て同じフォルダに入れてください。