http://manbow.nothing.sh/event/event.cgi?action=More_def&num=80&event=133

LR2IR : http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=296534

_GOWF_SP_NOVICEとズレなし

MISSレイヤーでココアちゃんを入りました

Rabi-Ribi難しい...NOVICEもやっとクリアした...