�{��:
https://extrose.stoicsounds.jp/_data/bms/gmtn/%2319%20%5BHARD%20RENAISSAYAKA%5D%20squartatrice.zip

obj.����:
https://muy4.github.io/muyacharts/index.html