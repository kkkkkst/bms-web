Poppy [opium]  obj : Mary_Sue
本体リンク：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=46&event=137
推定レベル：★23?
コメント：ポポポッポポポポッポポポポポ
本体リンクからダウンロードできる[saika]Poppy_empty.bms 基準ズレ抜けなし。