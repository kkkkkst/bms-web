Clockwork Grief [Uhrwerk] 
本体リンク：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=480&event=137
推定レベル：★23？（st4程度）
コメント：★22の天空の城ヴェリエルの感じがある高速乱打譜面です。よろしくお願いいたします。
　　　　　追記：差分目のUhrwerkはドイツ語で「時計仕掛け」という意味です

同梱Another基準ズレ抜けなし。

obj : Mary_Sue ( https://darksabun.github.io/Mary_Sue/ )