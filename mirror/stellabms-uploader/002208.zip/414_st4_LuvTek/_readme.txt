https://manbow.nothing.sh/event/event.cgi?action=More_def&num=414&event=140

DIFFICULTY: st4
NOTES: 2613
TOTAL: 442
JUDGERANK: EASY

同梱_bms.bm基準