be-music "<3" [no girlfriend since birth]
dandeless

本体：https://venue.bmssearch.net/romanticbms/8
推定レベル：★★5? 

BE-MUSIC Special Selection 2022 (https://hpx.getonpictochat.com/bmss/2022/) により
よろしくお願いいたします。

2023/05/08
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)