[Title]
BIRKIE [ちあふる] / [えなじぇてぃっく]

[Event URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=22&event=140

[Difficulty]
ちあふる : ★24 (st5-6)
えなじぇてぃっく : ★26 (st11-12)

[Comment]
ハネ＋ズレ差分
short arrange ver.のため、同梱譜面と比較すると物理的なズレや抜けがあります。
アレンジ差分のため、すべてのズレや抜けは意図的です。

！！！必ず同梱の下記2ファイルも本体フォルダに追加してください！！！
BGM4.ogg
BGM5.ogg