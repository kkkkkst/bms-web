PASSED OUT [Dumbo]
Pink Elephant / obj: Mary_Sue

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=30&event=112
推定レベル：★13?

Passedout_7.bmsとズレ抜けなし。よろしくお願いいたします。

2023/10/19 
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
