★23/st3? Moonrise (bms edit) [silence]

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=51&event=137

同梱Another譜面と比較してズレ抜けなし(Anzu BMS DIff Toolで確認)