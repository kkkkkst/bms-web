本体:https://bms-mirror.com/pkg/2021/bofxvii/Kagetora_Fragments.zip
★★3以上かと思われます。