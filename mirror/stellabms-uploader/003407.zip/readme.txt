URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=99&event=142

comment : SPI基準ズレX
대회 마감까지 2일밖에 남지 않아서 많이 뇌절치면서 st7?급까지로 맞춰보았습니다.

제목이 너무 난잡해지는거 같아서 작년에 써먹었던 그걸로 바꿨습니다.