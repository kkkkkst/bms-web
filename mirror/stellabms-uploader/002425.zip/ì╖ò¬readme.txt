楽曲本体をお持ちでない方は以下からどうぞ(当差分同梱済み)

https://drive.google.com/file/d/1gOwXg3QCSrGgi1SwdzGLqMdc_VloMY--/view?usp=share_link

