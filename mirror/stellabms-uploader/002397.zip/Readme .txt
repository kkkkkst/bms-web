[Title]
白き星姫-Принцесса белая звезда- [Антиутопия]

[Difficulty]
st10

[URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=129&event=104

[Comment]
連打差分
AnzuBMSDiffで同梱の「白き星姫A.bms」と比較してズレ抜けなし。
