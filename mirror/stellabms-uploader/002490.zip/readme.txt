[048]의 무음 SC 는 키음이 없어서 임의로 노트를 추가했습니다.
_Beginner 와 비교 시 키음 엇갈림과 누락이 없습니다.
읽어주셔서 감사합니다.

[048]の無音SCはキー音がなくて任意にノートを追加しました。
_Beginnerと比較すると、キー音のズレと漏れがありません。
お読み頂きましてありがとうございます.

Silent SC in [048] has arbitrarily added notes without key sounds.
There are no misalignment and omission of keys compared to _Beginner.
Thank you for reading it.