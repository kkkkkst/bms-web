[Title]
First Creation [Galaxy]

[Difficulty]
st11

[URL]
https://www.dropbox.com/s/fjccjz390i2vfbp/First%20Creation.rar?dl=1

[Comment]
連打差分

