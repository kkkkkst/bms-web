本体：https://web.archive.org/web/20071105054002/http://big.freett.com/mekurumeku/pushy.zip

bmson差分作成練習を兼ねて作りました。許して。
bmsonが再生できる本体（beatoraja等）を使用してください。

差分作成者：hyuki