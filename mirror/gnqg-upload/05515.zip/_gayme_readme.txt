�{�́Fhttp://manbow.nothing.sh/event/explus/ex_revival/bms/mcml.rar

All the zure are intentional.

~ https://twitter.com/marie_qune