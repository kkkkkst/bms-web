I Believeの差分(☆4～5くらいと≡4～5くらい)
本体URL → https://onedrive.live.com/?authkey=%21AIr4v9MWBYrS9h8&cid=FC95A680740CA8C9&id=FC95A680740CA8C9%2117830&parId=FC95A680740CA8C9%21111&o=OneUp

・Vertical7の方は追加音源を使用しているのでそれによるズレ抜けがあります
・両者ともに56小節目のWAV13を16分1つ分後ろにずらしています　そのためズレが検出されます