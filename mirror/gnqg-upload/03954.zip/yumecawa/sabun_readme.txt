本体URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=432&event=123


いくつか配置ミスと思われる箇所は下記の通り修正しています。
(同梱ANOTHER比較)

定義ミス修正
#090 #WAV01(q2leadm_000.wav) → #WAV7N(q2leadm_349.wav)

ズレ(?)修正
#034 #WAVOT(q2chordsm_181.wav) : 13/16 → 7/8
#041 #WAV5E(q2leadm_218.wav) : 9/16 → 5/8
#057 #WAVPQ(q2chordsm_248.wav) : 5/16 → 3/8
#059 #WAVW5(q2oneshot2m.ogg) : 13/16 → 7/8
#060 #WAVW5(q2oneshot2m.ogg) : 1/16 → 1/8
#063 #WAV4E(q2vocm_074.wav) : 3/16 → 1/4
#085 #WAVUM(q2chordsm_455.wav) : 1/16 → 1/8
#104 #WAVAW(q2drumm_108.wav) : 7/16 → 1/2
#112 #WAV1A(q2leadm_045.wav) : 1/16 → 1/8