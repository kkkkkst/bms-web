曲URL：https://onedrive.live.com/?cid=CA7A5144414EC4CA&id=CA7A5144414EC4CA!405

すべてのズレとノーツが抜けているのは意図的です。