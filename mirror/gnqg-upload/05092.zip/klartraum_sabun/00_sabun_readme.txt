本体URL：http://fuki1755.starfree.jp/bms/klartraum_dl.html

追加音源を全て同じフォルダに入れてください。
差分ファイルはアレンジされているため未配置ファイルと異なります。