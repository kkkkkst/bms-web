Hi. I stole this chart from some ares guy. 

The source code is here: https://github.com/Seraphin-/bms-sabuns/blob/master/metronogik/_SERA_make.py