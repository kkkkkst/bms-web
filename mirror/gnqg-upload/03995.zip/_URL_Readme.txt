﻿URL
https://dropbox.bms.ms/u/64302289/BMS/pentate_FUGU_wav.rar

README
差分と同梱の(スライス)キー音ファイルを必ず一緒に入れてください。
ズレ検査の結果は、それを示したもので実質ズレはありません。
(ベースとなるBMSファイルを.b拡張子で一緒に添付します。
このファイルと比較するとズレはありません。)

INFO
FUGU (HELL Version)
NOTES 3242
TOTAL 489
DIFFICULTY 22 (★22?)
JUDGERANK EASY

https://fsrs.github.io/

