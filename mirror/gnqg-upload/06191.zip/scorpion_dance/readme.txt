本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=15&event=96

出典（1008さんの差分）：https://youtu.be/VArnybjNlCk

LR2でのプレイ推奨です。例の譜面に倣い1つ作ってみました。よろしくおねがいします！


hyuki