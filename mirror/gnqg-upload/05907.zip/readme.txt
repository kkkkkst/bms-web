EVEVEN -7-
難易度：☆6くらい　局所的に難しいです

本体URL→https://roopdesign.net/post/34827532860/roop-bms-works-2004-2012