https://web.archive.org/web/20031204223047/http://www.ulis.ac.jp/~k250/web/dl.html
Bitplaneさんの以前のサイトにアップロードされたmp3ファイルを使用して元々配布されたbmsバージョンより少し長いバージョンを製作しました。
容量制限を守るために二重圧縮された追加音源があります。 忘れずに解凍をお願いします。 
ありがとうございます。

https://web.archive.org/web/20031005101330/http://www.ulis.ac.jp/~k250/web/about/index.html
上記リンクの内容によってmp3ファイルを利用しました。