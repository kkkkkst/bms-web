VEZZELiXめちゃくちゃ曲好きすぎて3時間で作りました
いつもの無理やり物量なので保証はしません 後半簡単かも
VEZZELってなに？

本体:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=98&event=133