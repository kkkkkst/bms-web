BMS URL: https://web.archive.org/web/20181106023102/http://www.geocities.jp/c_azabu/kazenomae_22k.zip

(オゴレルヒト) ★12
DP音源 DP譜面からズレ抜けなし確認済み

(タケキモノモ...) ★22
HARD譜面からズレ抜けなし確認済み
