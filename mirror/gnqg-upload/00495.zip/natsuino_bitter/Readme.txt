- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

�yBOFU2016 - Legendary Again - �ڍ׏��z 
�@No.581 "�i�c�C�m / Ino loves �݂����� & �����T�K(sweez) " - TEAM : STR MANIA 2ndMIX

�@http://manbow.nothing.sh/event/event.cgi?action=More_def&num=581&event=110

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 