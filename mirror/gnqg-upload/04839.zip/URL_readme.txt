曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=234&event=133
すべてのズレとノーツが抜けているのは意図的です。