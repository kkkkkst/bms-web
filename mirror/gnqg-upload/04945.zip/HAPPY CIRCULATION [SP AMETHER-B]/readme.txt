
IR
http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=295565

BMS公開ページ
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=158&event=83

インターネットアーカイブ
https://web.archive.org/web/20191224141644/http://black-funeral.kill.jp/HAPPY_CIRCULATION.zip/

差分公開ページ
http://ameria3141.web.fc2.com/bmssabun.html

譜面確認用YouTube
https://youtu.be/_lfM8ltZA44

