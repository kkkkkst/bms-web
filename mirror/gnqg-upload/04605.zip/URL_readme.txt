曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=35&event=132

_SEKIDO_5H.bmsと比較してズレないことを確認しました。