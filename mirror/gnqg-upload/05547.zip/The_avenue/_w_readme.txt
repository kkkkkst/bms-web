第三回BMS衆議院選 / The avenue / M-kani
obj. w

zure check: The_avenue_7a.bme

-HARD判定-

I really loved this song from shuin3. It's great for listening. I also think this song would make a really good ☆11 chart. ☆11 is my favorite difficulty level.

The song has many irregular rhythms coming from interweaving instruments, which I think is great for a HARD judge chart. I tried to make a chart that focuses on these irregular rhythms (with swing-y patterns).

I think my favorite kinds of songs are those with different instruments playing together, with different instruments becoming more prominent in different sections. As usual, I try to focus my patterning on which instruments I think are the most prominent in a section.

Interestingly, I think I would have made the chart differently for EASY and HARD judge. It seems like slow jack patterns are not difficult on HARD judge, but irregular scratch patterns are really difficult on HARD judge. I had to reduce the pattern complexity during the irregular scratch section due to HARD judge. I don't think I would have reduced the pattern complexity on EASY judge.

By the way, this song seems to actually have a lot of keysounds. High difficulty charts seem quite possible for this.

I didn't use the provided sabun template files because it has keysound misalignments(?) from the ANOTHER chart. It's strange, but I am sometimes afraid that sabun template files might have an outdated version of the keysounds (because bms makers may forget to update the template file when they update all their charts), so I usually try to use the ANOTHER instead when there is keysound misalignment.