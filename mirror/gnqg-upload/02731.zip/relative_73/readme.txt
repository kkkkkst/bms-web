���{��URL
relative / xra
http://web.archive.org/web/*/http://www.sango.sakura.ne.jp/~grey/Storage/relative.rar