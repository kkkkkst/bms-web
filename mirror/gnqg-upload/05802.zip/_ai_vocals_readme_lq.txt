��11/��1 �H��̃T���W��-Shou+rt Mix-

�{�́Fhttp://ofuton.tk/tarolabo/girizin.rar

/!\ You have downloaded the LQ version of this chart.
  The keysounds had to be compressed a lot to fit sabun uploader limits.
  Please consider downloading the HQ version here: https://www.dropbox.com/s/teidgnshu9ps019/sarazin_hq.zip?dl=0

AI was used to extract the vocals from BGM keysounds, I think the result is very surprising. extremely clean.

original chart used as a base for this: gazirin_05_05.bms
(if you're dedicated enough to check for zure against it)

~ https://twitter.com/marie_qune