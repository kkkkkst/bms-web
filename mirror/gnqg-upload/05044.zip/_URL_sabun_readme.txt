本体URL：https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/file/YMshlJqa

すべてのズレとノーツが抜けているのは意図的です。