�[ [V] / Kanata.S [obj. vi]

misalignment/�Y�� information:
the packaged hyper and another charts contain a misaligned note in measure 33.
the original version of this sabun was based on the hyper chart and hence had this error present as well.
the version you've downloaded fixes this, so it will pass the diff against the template (_plane.yuu) and normal chart.

discord quote from the artist:

���Ȃ��� Today at 7:38 PM
I am the author of The �[.
Actually, that song has an unintentional discrepancy in the 16th note interval in bar 33.
But that's about as far as it would seem if I thought of it as such a song...