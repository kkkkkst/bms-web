This is my first gachi 差分, hopefully it's fun to play!

大体URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=22&event=110

~ https://tilde.town/~marie/