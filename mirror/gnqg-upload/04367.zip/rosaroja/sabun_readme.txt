本体はBOF2010パッケージ保管から入手してください(2.1GB)

https://nekokan.dyndns.info/file/mirror/ceena-bms/%5bBMS%5d%5bPACK%5d%20THE%20BMS%20OF%20FIGHTERS%202010%20-The%20Evolution%20of%20War%20-%20Ver20101006/bof2010pack_part1.zip

LUMINOUS/hiironokamen


本体URL(リンク切れ):http://manbow.nothing.sh/event/event.cgi?action=More_def&num=124&event=65