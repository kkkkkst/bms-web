本体URL https://manbow.nothing.sh/event/event.cgi?action=More_def&num=261&event=116

all zure are intentional. i literally made half the song anyway so its ok