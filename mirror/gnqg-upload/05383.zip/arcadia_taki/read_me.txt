Arcadia [Totemism]
HaL feat. riri BGA fity / obj.瀧 廉太郎

★16-17

ACのズレガチ押しの練習に使う用に作った
今までの中では良い出来かも

@Xiro_iidx