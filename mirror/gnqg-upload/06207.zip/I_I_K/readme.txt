Impatience Impact - HAЯKDistortion VS Hiy
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=32&event=121

N、templateでズレ無し確認