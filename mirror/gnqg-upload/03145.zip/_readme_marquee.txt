�{��URL
https://mega.nz/#F!EpgWgJqa!7OItZfYLQxZ0X8OB19yvNQ!t0hD1axZ

LR2IR
http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=275248