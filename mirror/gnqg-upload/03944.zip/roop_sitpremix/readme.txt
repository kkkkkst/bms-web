一部wavファイルを切っているのでこのフォルダに入っているwavフォルダを本体ファイルにすべてコピーしてください

本体ファイルは“roop bms works 2004-2012”に入っています
DL: https://www.dropbox.com/s/7y7e3g3md4t4942/roopbmsworks2004-2012.zip


