bms diff toolにて本体同梱譜面である_7key.bmeと比較し、音ズレ・音抜けが無いことを確認済みです。

本体URL:http://sound.jp/underthe/index.htm