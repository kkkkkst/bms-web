本体URL：http://keyc.s12.xrea.com/files/c03-worlds.rar
BGA：https://mega.nz/folder/sXZTFSxS#UX7Cpqoi03tRQ-jpzn8F6A/file/tOpSXaxY

追加音源を全て同じフォルダに入れてください。
Sliced by DAC (https://fsrs.github.io/)