本体URL→http://manbow.nothing.sh/event/event.cgi?action=More_def&num=79&event=44

BACO氏のDENGEKI Tubeの皿差分です
電気は☆11ぐらい