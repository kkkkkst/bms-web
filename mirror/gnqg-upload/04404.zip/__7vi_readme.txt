8 Sentence "To you favorite" [MMVI] / spinai [obj.vi]

misalignment check information:

- used tool: https://stairway.sakura.ne.jp/smalltools/minibmsplay/diff.htm
- checked against 5key pattern (_5.bms), no errors
- checking against both 7key patterns results in errors!