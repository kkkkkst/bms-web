本体URL：http://offtime.sakura.ne.jp/bms/
同梱Anotherと比較し、ズレ抜け無いことを確認済

st11-12
Blue-White Crazystars [GOD]
譜面傾向：超高速重発狂、少しガチ押し

Anotherを再構成して癖の少ない物量譜面にしました。