以前作った譜面のリメイク？強化版と弱化版です。
A譜面とズレがないです。
本体:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=11&event=126