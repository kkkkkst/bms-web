本体URL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=401&event=137
難易度：sl7想定
＊N,H音源に合わせるために一部の定義を変更したり、音を足している部分があります（WAV23～2Zの定義変更とK3にwobble.wavを追加）。
　それ以外の部分においては_Outernoid_差分制作用と比較してズレ抜けが無いことを確認しています。