Nov. 26, 2019
7K sabun #12 | KAIGO / 空読無 白眼
- NORMAL 6
- HYPER 8
- ANOTHER 10

Hueeaaa~ Foo~

I really wanted to make 7K patterns for this song as I think it's really catchy and has excellent BGA work. For those who find these too easy, AYhaz has also made a ☆6 pattern for it here: http://gnqg.rosx.net/upload/upload.cgi?get=03611

I thought the most important part of charting a song with lots of tribal rhythms like this was to focus each part to make one rhythm stand out and feel really impactful to hit. Because of this, this song was trickier to make a pattern for on ANOTHER where there's more keys to hit at once. I recommend playing the lower level patterns as well as I think they turned out quite fun.

- hyso (Hyparpax)