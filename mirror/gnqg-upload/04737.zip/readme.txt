曲聞いた瞬間に譜面浮かんだので形にしました
下位譜面はトータルとかノーツ数とかこだわりました
めちゃくちゃ曲がいいので譜面負けしないようにがんばりました

本体:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=35&event=133