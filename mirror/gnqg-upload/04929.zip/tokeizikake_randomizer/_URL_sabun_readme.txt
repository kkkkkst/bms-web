﻿本体URL：http://www.mediafire.com/file/5x7aeezm20yvlgq/tokeizikake.rar/file

追加音源を全て同じフォルダに入れてください。

Randomize script by Sera (https://github.com/Seraphin-/bms-sabuns)