曲URL：https://web.archive.org/web/20110625181433/http://www.geocities.jp/panda_bms/cold_planet.zip

HOT COCOA (★18) / Obj：И

ダウンロードありがとうございます。 追加音源を全て同じフォルダに入れてください。

ICE AMERICANO (★★4) / Obj：2RLZ

何卒よろしくお願い致します。