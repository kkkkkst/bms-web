曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=492&event=133

_BEYOND_a_base.bmx, _Beyond_h_base.bmxと比較してズレないことを確認しました。