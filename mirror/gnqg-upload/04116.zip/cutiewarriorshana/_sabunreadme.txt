Anzu BMS Diff Toolにて本体同梱譜面である_hyper.bmsと比較し、音ズレ・音抜けが無いことを確認済みです。

本体URL:https://event.yaruki0.net/VSevent/impression/11