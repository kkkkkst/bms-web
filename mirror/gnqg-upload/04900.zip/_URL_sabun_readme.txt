本体URL：https://web.archive.org/web/20070703051913/http://sasakure.bms.ms/bms/imazinexoMQver1.1.zip

すべてのズレとノーツが抜けているのは意図的です。