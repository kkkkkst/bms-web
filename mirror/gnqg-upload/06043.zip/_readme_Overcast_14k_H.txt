First time charting 14k(I did two 10k charts before)
DM me on discord only to say how bad it is
SOUNDSPHERE BEST GAME#4511