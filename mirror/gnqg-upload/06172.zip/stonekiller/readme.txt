本体：http://onedrive.live.com/?cid=40805CD20B6241C6&id=40805CD20B6241C6!1915

注意点
・HS-FIX推奨です。
・運ゲー要素あり。

出典1：StoneKiller120
http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsmd5=981d55216addb6f44096e847c859aa53
配置はすべてこちらの譜面と同じです。

出典2：Rehabilitation [乱打と速度]
http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsmd5=66019d77a0fc91c9befc8574b121ca5f
緑数字一定で速度とBPM表示を変化させる技術を勝手に頂戴しました。

出典3：era (Cyberia ∞ mix)
http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsmd5=6d53512547d425c0dbe574b5f65e59b7
ランダムソフラン技術の参考。





速度ギミック入れた人：hyuki