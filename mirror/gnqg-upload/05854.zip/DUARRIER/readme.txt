過去に配布したネタ差分「DUARRIER [Tenosynovitis]」も同梱しています。★★6～★★7相当の連打差分です。

動画リンク
https://www.youtube.com/watch?v=MM8RKCnqi6U
