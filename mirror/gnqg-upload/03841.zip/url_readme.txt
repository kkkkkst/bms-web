曲URL：http://web.archive.org/web/20071210121840/http://www14.plala.or.jp/sun3_bms/Re_final.rar

2つの譜面を準備してみました。 何回もプレイしてください。（#RANDOM利用）

Obj：(^v^)/ + (^ω^)/