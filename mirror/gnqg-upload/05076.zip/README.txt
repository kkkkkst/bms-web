this song was begging for a harder chart so i gave it my best.
not completely satisfied with the ending but what can you do.
chart better, that's what you can do

�{��: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=269&event=133

~ https://tilde.town/~marie/