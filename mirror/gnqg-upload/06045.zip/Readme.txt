Pandora [Forbidden Boxes]

★★5-6(st10-11)

ディレイ付加によるズレがあります。
AnzuBMSDiff toolで同梱の「_ANOTHER.bms」と比較して意図しないズレがないことを確認済。
(アレンジ差分)