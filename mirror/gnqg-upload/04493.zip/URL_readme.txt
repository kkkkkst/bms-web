曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=13&event=127

84小節のGWノーツは意図的なズレです。
Project AGの一部のパートはAlpha-Gorilaを使用しました。

BMS Object Auto Placement Program "Alpha-Gorila"
https://fsrs.github.io/lab.html