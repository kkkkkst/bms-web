��0 macron -demission-

/!\ THIS IS FOR THE 2015 REMAKE /!\

�{�́F�uest124_macaron2.zip�v
https://onedrive.live.com/?id=F61C1F8825F0CF46%21159&cid=F61C1F8825F0CF46

����Fhttps://www.youtube.com/watch?v=0mvZesJdNTA

---

learned a few new things while making this chart.

namely, this is the first time I use a spreadsheet
to generate barline gimmicks (the mines were still
placed by hand afterwards).

I wanted the animation to be smoother originally,
but using any division lower than 1/16 resulted in
too many barlines (e.g. 1152 for 1/24) so that turned
out to be impossible. thankfully, it's still pretty
readable as it is now!

ran into a lot of issues and crashes with iBMSC while
making this. thankfully I managed to pull through,
even if everything is not 100% how i'd want it to be!

I think this chart is very fun to play, please play it!

---

please also check out �ubaby blue blanquer -demission-�v
by AXION: https://www.youtube.com/watch?v=nxubPuue5OE

~ https://twitter.com/marie_qune