[TITLE / ARTIST]
ヤマダ電機の店内でよく流れてるアレ (Hardcore mix) / この前初めてヤマダ電機に入ったpolysha 様

[本体URL]
https://web.archive.org/web/20140126062710/http://cineraria-studio.com/minimani/files/31/yamadadenki_ogg.zip

[推定難易度]
★★5-★★6弱？

[この差分について]
本差分はアレンジ差分です。すべてのズレや抜けは意図されたものです。