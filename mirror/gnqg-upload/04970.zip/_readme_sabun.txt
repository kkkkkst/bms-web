5.Sky Angelus

「Sky Angelus」のDP差分です。
kawaii譜面の構成は同梱譜面のINSANEを踏襲しています。

DIFFICULTY　 　　　  NOTES     TOTAL
DP NORMAL　 :☆4　　 405Notes 　350
DP HYPER　  :☆9 　  996Notes 　400
DP ANOTHER  :☆11　 1644Notes 　450
kawaii　　  :☆12　 1901Notes 　500

全譜面同梱NORMAL譜面と比較してズレ抜け無しです。

本体：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=5&event=115

差分：フォルティッシモ