
IR
http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=290450

BMS
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=90&event=132

差分
http://ameria3141.web.fc2.com/bmssabun.html

譜面確認用
https://www.youtube.com/watch?v=teRZCwUgy8E

