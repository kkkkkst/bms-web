曲URL：https://dl.dropboxusercontent.com/sh/xrr3fvlhagzsmm2/AADrcgFDWT6axiabf5LwN9qia/bms/hurt%2Cscenery%2Cgroundrainbow.rar
追加音源(wav)：https://bms.parksulab.xyz

追加音源を全て同じフォルダに入れてください。