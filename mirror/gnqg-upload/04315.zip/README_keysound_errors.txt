この差分は音ズレがありません。
この曲のSPN、SPH、SPA、差分templateはキー音のエラーがあります。

There are no misaligned keysounds in this sabun.
The SPN, SPH, SPA charts, as well as the sabun template, all have keysound errors.

Explanation:

SPN: Measure #028 has missing [5E] keysound objects.
SPH: Duplicate keysound objects in measures #024-#026
SPA: Different guitar keysounds are used in the final measure (#067)
template: Extra [01] keysound object in measure 2. This is an error.

I believe fancy bus [W] has the correct keysounds.



**********************************
Anzu BMS Diff Tool output:
**********************************

X : "fancybusw.bms" 2901 objs (無音除く)
Y : "fancybusn.bms" 2885 objs (無音除く)


******** difference check ********
bar position    wavid
#028 18 (0 / 1) #WAV5E is missing in Y. (ch.wav)
#028 01 (1 / 4) #WAV5E is missing in Y. (ch.wav)
#028 01 (1 / 2) #WAV5E is missing in Y. (ch.wav)
#028 01 (3 / 4) #WAV5E is missing in Y. (ch.wav)
#029 01 (0 / 1) #WAV5E is missing in Y. (ch.wav)
#029 01 (1 / 4) #WAV5E is missing in Y. (ch.wav)
#029 01 (1 / 2) #WAV5E is missing in Y. (ch.wav)
#029 01 (3 / 4) #WAV5E is missing in Y. (ch.wav)
#030 01 (0 / 1) #WAV5E is missing in Y. (ch.wav)
#030 01 (1 / 4) #WAV5E is missing in Y. (ch.wav)
#030 01 (1 / 2) #WAV5E is missing in Y. (ch.wav)
#030 01 (3 / 4) #WAV5E is missing in Y. (ch.wav)
#031 01 (0 / 1) #WAV5E is missing in Y. (ch.wav)
#031 01 (1 / 4) #WAV5E is missing in Y. (ch.wav)
#031 01 (1 / 2) #WAV5E is missing in Y. (ch.wav)
#031 01 (3 / 4) #WAV5E is missing in Y. (ch.wav)

******** 16 errors found. ********

******** end of report ********


#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#


X : "fancybusw.bms" 2901 objs (無音除く)
Y : "fancybusa.bms" 2901 objs (無音除く)


******** difference check ********
bar position    wavid
#067 19 (11 / 32)   #WAV1H is missing in X. (g1.wav)
#067 12 (11 / 32)   #WAV0K is missing in Y. (guitar_014.wav)
#067 12 (13 / 32)   #WAV1H is missing in Y. (g1.wav)
#067 19 (13 / 32)   #WAV0H is missing in X. (guitar_013.wav)
#067 12 (15 / 32)   #WAV1I is missing in Y. (g2.wav)
#067 18 (15 / 32)   #WAV0H is missing in X. (guitar_013.wav)
#067 12 (17 / 32)   #WAV1J is missing in Y. (g3.wav)
#067 19 (17 / 32)   #WAV1L is missing in X. (g5.wav)
#067 12 (19 / 32)   #WAV1K is missing in Y. (g4.wav)
#067 18 (19 / 32)   #WAV1M is missing in X. (g6.wav)
#067 12 (21 / 32)   #WAV1L is missing in Y. (g5.wav)
#067 19 (21 / 32)   #WAV1N is missing in X. (g7.wav)
#067 12 (23 / 32)   #WAV1M is missing in Y. (g6.wav)
#067 18 (23 / 32)   #WAV1O is missing in X. (g8.wav)
#067 12 (25 / 32)   #WAV1N is missing in Y. (g7.wav)
#067 19 (25 / 32)   #WAV1P is missing in X. (g9.wav)
#067 18 (27 / 32)   #WAV1Q is missing in X. (g10.wav)
#067 12 (27 / 32)   #WAV1O is missing in Y. (g8.wav)
#067 19 (29 / 32)   #WAV1R is missing in X. (g11.wav)
#067 01 (29 / 32)   #WAV1P is missing in Y. (g9.wav)
#067 01 (31 / 32)   #WAV1Q is missing in Y. (g10.wav)
#067 18 (31 / 32)   #WAV1S is missing in X. (g12.wav)

******** 22 errors found. ********

******** end of report ********


#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#


X : "fancybusw.bms" 2901 objs (無音除く)
Y : "fancybush.bms" 2941 objs (無音除く)

******** duplicate check ********
bar position    wavid
#024 01 (0 / 1) #WAV34 is duplicated in Y. (synth_003.wav)
#024 14 (1 / 16)    #WAV39 is duplicated in Y. (synth_006.wav)
#024 19 (1 / 8) #WAV3H is duplicated in Y. (synth_009.wav)
#024 14 (3 / 16)    #WAV3A is duplicated in Y. (synth_006.wav)
#024 12 (1 / 4) #WAV34 is duplicated in Y. (synth_003.wav)
#024 14 (5 / 16)    #WAV38 is duplicated in Y. (synth_006.wav)
#024 01 (3 / 8) #WAV3G is duplicated in Y. (synth_009.wav)
#024 14 (7 / 16)    #WAV39 is duplicated in Y. (synth_006.wav)
#024 13 (1 / 2) #WAV33 is duplicated in Y. (synth_002.wav)
#024 14 (9 / 16)    #WAV3A is duplicated in Y. (synth_006.wav)
#024 01 (5 / 8) #WAV3F is duplicated in Y. (synth_008.wav)
#024 01 (11 / 16)   #WAV38 is duplicated in Y. (synth_006.wav)
#024 12 (3 / 4) #WAV32 is duplicated in Y. (synth_001.wav)
#024 14 (13 / 16)   #WAV39 is duplicated in Y. (synth_006.wav)
#024 01 (7 / 8) #WAV3B is duplicated in Y. (synth_007.wav)
#024 01 (15 / 16)   #WAV3A is duplicated in Y. (synth_006.wav)
#025 13 (0 / 1) #WAV37 is duplicated in Y. (synth_005.wav)
#025 15 (1 / 16)    #WAV3B is duplicated in Y. (synth_007.wav)
#025 19 (1 / 8) #WAV3I is duplicated in Y. (synth_010.wav)
#025 15 (3 / 16)    #WAV3C is duplicated in Y. (synth_007.wav)
#025 01 (1 / 4) #WAV37 is duplicated in Y. (synth_005.wav)
#025 01 (5 / 16)    #WAV3C is duplicated in Y. (synth_007.wav)
#025 01 (3 / 8) #WAV3J is duplicated in Y. (synth_010.wav)
#025 15 (7 / 16)    #WAV3C is duplicated in Y. (synth_007.wav)
#025 12 (1 / 2) #WAV37 is duplicated in Y. (synth_005.wav)
#025 01 (9 / 16)    #WAV38 is duplicated in Y. (synth_006.wav)
#025 15 (5 / 8) #WAV3D is duplicated in Y. (synth_008.wav)
#025 14 (11 / 16)   #WAV39 is duplicated in Y. (synth_006.wav)
#025 12 (3 / 4) #WAV33 is duplicated in Y. (synth_002.wav)
#025 01 (13 / 16)   #WAV3A is duplicated in Y. (synth_006.wav)
#025 18 (7 / 8) #WAV3G is duplicated in Y. (synth_009.wav)
#025 01 (15 / 16)   #WAV38 is duplicated in Y. (synth_006.wav)
#026 01 (0 / 1) #WAV34 is duplicated in Y. (synth_003.wav)
#026 01 (1 / 16)    #WAV39 is duplicated in Y. (synth_006.wav)
#026 01 (1 / 8) #WAV3G is duplicated in Y. (synth_009.wav)
#026 01 (3 / 16)    #WAV3A is duplicated in Y. (synth_006.wav)
#026 01 (1 / 4) #WAV34 is duplicated in Y. (synth_003.wav)
#026 14 (5 / 16)    #WAV38 is duplicated in Y. (synth_006.wav)
#026 18 (3 / 8) #WAV3G is duplicated in Y. (synth_009.wav)
#026 14 (7 / 16)    #WAV39 is duplicated in Y. (synth_006.wav)

******** 40 errors found. ********

******** end of report ********


#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#


X : "fancybusw.bms" 2901 objs (無音除く)
Y : "fancybus.sab" 2902 objs (無音除く)


******** difference check ********
bar position    wavid
#002 01 (3 / 8) #WAV01 is missing in X. (guitar_000.wav)

******** meta info check ********
Artist Entries are different. (X : "First Class", Y : "First Class Flight")

******** 2 errors found. ********

******** end of report ********