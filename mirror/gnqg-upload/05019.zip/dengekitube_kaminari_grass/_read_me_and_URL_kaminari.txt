本体URL→http://manbow.nothing.sh/event/event.cgi?action=More_def&num=79&event=44

BACO氏のDENGEKI Tubeの皿差分です
雷は★★6だか7ぐらい、無理ゲー
雷起こしは手動ディレイ皿となっているためキー音が滅茶苦茶増えています