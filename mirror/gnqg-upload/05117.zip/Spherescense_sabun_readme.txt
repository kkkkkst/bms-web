URL: https://venue.bmssearch.net/bmsshuin3/42

Reference: https://youtu.be/0P8HvN6knVg?t=92