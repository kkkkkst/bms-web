�{�́Fhttp://manbow.nothing.sh/event/event.cgi?action=More_def&num=444&event=133
����Fhttps://www.youtube.com/watch?v=BUYtVuDpCJk

*------------------------[ Notes ]-------------------------*
|                                                          |
| Minor  sightreadable BPM gimmicks  are fun!  Apart  from |
| these,  this is a fairly  standard mid-BPM  gachi chart, |
| although  I  did   pay  very  close  attention   to  the |
| consistency of the patterns. Please have fun playing it! |
|                                                          |
*----------------------------------------------------------*

*-----------------[ Misalignment Notice ]------------------*
|                                                          |
| The BPM  changes trip up  AnzuBMSDiff, but  there are no |
| actual zure (checked with a different  file that has the |
| bpm changes removed).                                    |
|                                                          |
*----------------------------------------------------------*

2021-07-27: fixed accidental zure

~ http://tilde.town/~marie/