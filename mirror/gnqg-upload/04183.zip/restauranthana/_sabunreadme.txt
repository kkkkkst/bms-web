Anzu BMS Diff Toolにて本体同梱譜面である_RestaurantLittleGarden_A.bmsと比較し、音ズレ・音抜けが無いことを確認済みです。

本体URL:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=92&event=123