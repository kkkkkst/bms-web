本体URL : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=325&event=127

obj.2RLZ : 何卒よろしくお願い致します。
