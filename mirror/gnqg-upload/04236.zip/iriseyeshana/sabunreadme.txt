Anzu BMS Diff Toolにて本体同梱譜面であるIrisEyes_L.bmeと比較し、音ズレ・音抜けが無いことを確認済みです。
本体URL:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=10&event=129