本体URL：https://web.archive.org/web/20120623132756/http://diverse.jp/download/rsgr.rar

2KEYS → 2KEYS CONSTANT