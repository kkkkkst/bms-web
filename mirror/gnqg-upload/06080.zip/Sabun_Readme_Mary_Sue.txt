Mary_Sue's Sabun Page : https://darksabun.github.io/Mary_Sue/
連絡先：https://twitter.com/MarySue_BMS

本体リンク：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=137&event=127

＊＊検出されたズレ、抜けについて＊＊
追加音切りのせいで、同梱Another基準51小節のW7と55小節のW8キー音がズレています。プレイには特に問題ありません。圧縮された追加キー音ファイルは全部本体フォルダに解凍してください。

검출되는 즈레에 관하여
즈레 검사를 해보면 동봉 어나더 기준 51소절의 W7 키음과 55소절의 W8 키음이 없다고 나오는데, 전부 키음을 잘라서 생긴 즈레입니다. 차분 파일에 동봉된 추가키음을 모두 곡 폴더에 넣어주세요.
