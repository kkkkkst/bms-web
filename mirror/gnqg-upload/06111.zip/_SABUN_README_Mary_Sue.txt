本体URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=197&event=104

同梱 _差分製作用　基準ズレ抜けなし。