☆7 Mazarine -Novice-
Total : 284(100%) かなりの後半難。

本体URL→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=18&event=132