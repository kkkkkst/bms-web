曲URL：https://onedrive.live.com/?cid=f0fdd6d137c174fa&id=F0FDD6D137C174FA%21239&lor=shortUrl

曲の一部の区間を切り、キー音を追加したために検出される全てのエラーは意図的なものです。