曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=490&event=110

_Grimheart(A).bmsと比較してズレないことを確認しました。

BMS Object Auto Placement Program "α-Gorila"
https://fsrs.github.io/lab.html