DANCE & (wish me a) MERRY CHRISTMAS! -7lines Maniac-
難易度：≡3くらい

第2作目の差分
クリスマスイブの夜に咄嗟に思いついて勢いで作りました　ラストがひどい
短めの縦連打と軸譜面です　2次配布とかはご自由にどうぞ