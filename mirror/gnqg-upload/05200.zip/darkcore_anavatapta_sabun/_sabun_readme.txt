本体URL：http://sunaneko.iptime.org/BMS_Library/Anavatapta%20%28by%20ikaruga_nex%29.rar

追加音源を全て同じフォルダに入れてください。