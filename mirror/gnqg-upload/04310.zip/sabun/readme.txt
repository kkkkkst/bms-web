本体URL:https://beatmaniauet.wixsite.com/kusekorebmspack2020

#LNMODE 2にしてあるのでbeatorajaだとCN固定になります。