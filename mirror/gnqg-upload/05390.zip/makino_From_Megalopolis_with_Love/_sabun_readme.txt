本体URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=9&event=124

追加音源を全て同じフォルダに入れてください。