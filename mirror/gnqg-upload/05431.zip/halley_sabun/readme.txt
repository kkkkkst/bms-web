
 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

・譜面内容

　7KEYS
　　[Back to the 1986] : ★1

　9BUTTONS
　　[9Key EASY]        : Lv.10
　　[9Key NORMAL]      : Lv.18
　　[9Key HYPER]       : Lv.32
　　[9Key EX]          : Lv.43

 - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
