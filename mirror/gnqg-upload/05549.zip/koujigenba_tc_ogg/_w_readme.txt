World War / Beats and Bites / Thefur Celtridorn
obj. w

zure check: 0704.bms

[2KEYS]

After making Legend of Eastern Rabbit [2KEYS], I felt like should make a less difficult 2KEYS chart, one that more people can play.

This is a chart with a lot of repetition. I think repetition matches the song well. Playing the chart is about maintaining your rhythm on a fixed, repeating pattern. I feel like the most difficult parts are the transitions between patterns.

The middle section of the chart can be quite tiring to play. It's a pattern that makes the player tense, to match the intensity of the music.


-HARD判定-

The another chart for this song has some very fun jacks. I thought it would make a good HARD judge chart on its own.
The initial plan was to just change the judge rank to hard and post it as a sabun, but it felt awkward to do that. So I decided to try making it into my own chart.

The patterns are heavily influenced by the original chart, but I added more jacks and LNs, removed some of the awkward bursts, and changed some of the patterns so that the chart will be less random-dependent. The original chart had some patterns which were designed to be played on non-random (like jacks on one hand and stairs on the other hand).

Also, I changed the slowdown so that it is no longer unfair for sightreading(初見). The BPM slows down during a single LN so it is easy to react to, and I added measure lines so that it is easy to see exactly where the slowdown is.

One thing I did in this chart isto avoid placing jacks during LN notes. Jack+LN notes can be quite tricky to play, especially on HARD judge. I wanted this chart to be relatively straightforward.

Low BPM, low difficulty, HARD judge. I feel like everyone will just S-RAN this chart. Timing is usually much easier on S-RAN for charts like this. However, on S-RAN, there will be jacks during the LN notes, which can be a little tricky.