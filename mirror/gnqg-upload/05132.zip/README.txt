�{�́F https://event.yaruki0.net/VSevent/impression/13

please don't expect anything particularly original or
good from my charts labeled �i�E���E�I�j as they are mainly a
means for me to experiment with different patterns.
i hope you still have fun playing them though!

note:
keysounds have been rearranged to allow for chordstreams.

~ https://tilde.town/~marie/