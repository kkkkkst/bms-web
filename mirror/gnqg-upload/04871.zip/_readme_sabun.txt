4.The Heroine Appears.

「The Heroine Appears.」のDP差分です。
DPN～DPAが同梱されているBMSでしたので、
DPHとDPAの間、DPAの上を補完する譜面を制作いたしました。
押しづらい配置や多数同時押しをメインに置いた譜面となります。

DIFFICULTY　 　　　  NOTES     TOTAL
DP HARD　　 :☆11　 1321Notes 　450
UNDYING　　 :☆13　 1947Notes 　550

本体：https://onedrive.live.com/redir?resid=C9FE89A646FB0230!4213&authkey=!AKb6aYXk_F1twJg&ithint=file%2czip

差分：フォルティッシモ