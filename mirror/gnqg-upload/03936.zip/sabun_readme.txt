曲URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=171&event=96

同梱HYPER譜面と比較してズレないことを確認しました。

TITLE	 SIDE:M		 SIDE:И
DIFF?	 ★17~18?	 ★14~15?
NOTES	 2020		 2075
TOTAL 	 456		 400
RENDA?	 MANY		 SLIGHT
PATTERN	 M-SPIИ		 M-SPIИ
FUN?	 AWESOME!	 AWESOME!