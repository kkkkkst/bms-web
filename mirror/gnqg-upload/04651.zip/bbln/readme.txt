本体URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=40&event=118

SPN比較ズレ抜け無し