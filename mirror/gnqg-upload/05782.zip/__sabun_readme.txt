本体URL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=56&event=137

_BEAT.bmlと比較してズレないことを確認しました。