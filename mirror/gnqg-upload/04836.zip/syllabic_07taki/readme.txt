Tribal Techno
syllabic [Seven Sense]
siromaru / obj.瀧 廉太郎
★16～18

初めて譜面制作したので雑な所多いところ多いと思うけどお許しを
そもそもTechnoって曲調もフレーズ単調だから譜面に起こすとう～んってなるんすよね、曲は素晴らしいんだけどな…
縦連、中速、横認識の練習にどうぞ

曲リンク:https://www.dropbox.com/s/z6uulc5qaxdpahz/syllabic_07cloudy.zip?dl=0