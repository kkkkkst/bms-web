2.DOLL

「DOLL」のDP差分です。
音切りの特殊さや連番bmp等レトロチックな作風のBMSですが、
あえて今風の譜面を作りました。
どの譜面もサビの階段が押せるかにかかっていますので頑張ってください。

DIFFICULTY　 　　　  NOTES     TOTAL
DP NORMAL　 :☆5　　 500Notes 　333
DP HYPER　  :☆9　　 952Notes 　444
DP HARD　　 :☆11　 1226Notes 　500
DP ANOTHER  :☆12　 1656Notes 　555

DP HARD･･･没譜面ですがHとAの難易度差が広がってしまったので入れています。
なので他の譜面とは一風変わった配置になっています。
階段要素が前面に出ている譜面なので階段の練習にどうぞ。

本体:https://web.archive.org/web/20151030093509/http://mikihara.cheap.jp/bms/BOF2015/doll_ogg.zip

差分：フォルティッシモ