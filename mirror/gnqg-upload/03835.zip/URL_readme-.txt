﻿http://manbow.nothing.sh/event/event.cgi?action=More_def&num=285&event=127

α-Gorila様のデビュー差分です。Gorillaではない。
使用するオブジェクトを指定してくれるから30秒ぶりに素敵な乱打差分を作ってくれました。
-LuvTek