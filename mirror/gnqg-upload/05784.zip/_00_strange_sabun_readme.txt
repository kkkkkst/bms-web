本体URL：https://1drv.ms/u/s!AgF3AxufJ8SgheVW76lqfMaq5Km-lQ
イベントURL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=7&event=133

_00_strange.bと比較してズレないことを確認しました。