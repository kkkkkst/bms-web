�{��:https://shiraishi2007.exblog.jp/27987601/

wanted to play a moon-gate chart around ��20
but without delay so i made one!

~ https://tilde.town/~marie/