本体URL/Song URL: http://web.archive.org/web/20090217182804/http://vfpq.fau.jp/event/vc/vc01/detail/6.php

Charter's Note:  Finally I'm able to participate in a BMS Chart Editor's Group Event!  This song is faimliar to some who are familiar with xi's work Happy End Of The World.  I immediately thought of Blocko when I saw xi had this edit in BMS.  Blocko has created dozens of charts for Happy End of the World, so I knew I had to dedicate this chart to him.  I know the difficulty on this chart is Stella/Overjoy, but I hope those that play it can enjoy the climatic swell of emotions this song produces.  Thank you very much.  --Tristan97

（翻訳が悪い）
チャーターのメモ：BMSチャートエディターのグループイベントにようやく参加できてうれしいです！この曲は、xiの作品「ハッピーエンドオブザワールド」に精通している人には馴染みのあるものです。 BlockoはHappy End of the Worldのために数十のチャートを作成したので、私は自分のスコアを彼に捧げることにしました。このチャートの難しさはStella / Overjoyであることは知っていますが、この曲を演奏する人がこの曲が生み出す感情的な気候のうねりを楽しむことができることを願っています。ありがとうございました。-Tristan97