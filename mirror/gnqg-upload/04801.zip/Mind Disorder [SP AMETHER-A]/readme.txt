
IR
http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=293316

BMS
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=71&event=133

差分
http://ameria3141.web.fc2.com/bmssabun.html

譜面確認用YouTube
https://www.youtube.com/watch?v=WucexWUbvWg

