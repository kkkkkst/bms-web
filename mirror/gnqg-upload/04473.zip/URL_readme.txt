曲URL：https://venue.bmssearch.net/bmsshuin2/57

_DistortedIntelligence_00_blanc.bmxと比べてズレないことを確認しました。