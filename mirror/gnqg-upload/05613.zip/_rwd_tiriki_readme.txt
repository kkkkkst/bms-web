�{��URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=16&event=134

zure check: _rwd_0+

intentional differences:
* bpm was changed (except for _rwd_tiriki1.bms)
* non keysounded notes (Z0) were used in some places