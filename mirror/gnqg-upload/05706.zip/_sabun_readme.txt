本体URL：https://www.nekomirin.com/bms/nekomirin_vg_HQogg.zip

_vg_02_normal7.bmlと比較してズレないことを確認しました。