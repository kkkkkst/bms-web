
IR
　http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=301710

BMS公開ページ
　http://manbow.nothing.sh/event/event.cgi?action=More_def&num=5&event=69
補完
　https://www.dropbox.com/s/dtm9bubdl9spi8b/HAPPY%E2%98%86LUCKY%E2%98%86BABY.zip?dl=0

差分公開ページ
　http://ameria3141.web.fc2.com/bmssabun.html

譜面確認用YouTube
　https://youtu.be/p7NkGAd5QyA

