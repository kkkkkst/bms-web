曲URL：https://onedrive.live.com/?cid=26D9698EC1CEC044&id=26D9698EC1CEC044%21208
BGA URL：https://web.archive.org/web/20130327072721/http://www.planetoid.biz/bga/wl_ray_bgahq.rar

追加音源を全て同じフォルダに入れてください。

