本体URL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=153&event=137

_no_pattern.無配置と比較してズレないことを確認しました。