[Title]
Streiflicht [Starlight]

[Event URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=424&event=133

[Difficulty]
★★6(st10)

[Comment]
連打とズレ物量
アレンジ差分のため、ディレイ等の付加によるズレがあります。
AnzuBMSDiff toolで同梱の「_Streiflicht_7normal.bms」と比較して
意図しないズレがないことを確認済。




[Promotion (old chart)]

Pandora [Forbidden Boxes]

★★5-6(st9-10)
連打とディレイ

Event&Chart URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=153&event=137
http://gnqg.rosx.net/upload/upload.cgi?get=06045