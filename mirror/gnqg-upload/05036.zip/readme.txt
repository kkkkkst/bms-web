本体:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=233&event=127
あっためてそのままだったので完成させときました