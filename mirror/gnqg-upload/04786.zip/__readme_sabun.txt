3.disperagioia

「disperagioia」のDP差分です。
あるコンセプトの元に配置いたしました。
DB配置多め・局所難な譜面となっております。

DIFFICULTY　 　　　  NOTES     TOTAL
DP NORMAL　 :☆7　　 872Notes 　400
DP HYPER　  :☆11　 1691Notes 　500
DP ANOTHER  :☆12　 2345Notes 　550
Decretum　　:☆13　 2727Notes　 600

全譜面同梱NORMAL譜面と比較してズレ抜け無しです。

本体:http://web.archive.org/web/20180124133508/http://gmtn.sub.jp/bofu2017_disperagioia.zip

差分：フォルティッシモ