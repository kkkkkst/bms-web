配信で作ったもの以外に2つ差分を用意してみました。




[CHAOS Special HARD]

NOTES 668
TOTAL 125
判定 HARD
停止回数 54回

[CHAOS Special]よりも辛くなった判定、増量された地雷、そして重くなったゲージ。
配信中にいらっしゃった方の意見を反映してみたら、私好みの譜面になってしまいました。
かなりのマニア向け難易度となっております。ご注意ください。




[lots respects]

あの伝説のギミックをもう一度。
出典：http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsmd5=7b44b5c6c6ae1612ebbc343090291a97