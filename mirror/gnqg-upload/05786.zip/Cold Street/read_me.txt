本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=335&event=123


本差分をダウンロードして下さりありがとうございます。

この差分はギミック譜面作成配信を行った際に出来上がったものです。（いくつか手直しした部分はありますが）
良ければ作成の模様をアーカイブにてご覧ください。

配信URL：https://youtu.be/U-cS5wl_7QQ




[CHAOS special]

NOTES 668
TOTAL 250
判定 EASY
停止回数 54回
