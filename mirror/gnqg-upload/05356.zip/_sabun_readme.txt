本体URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=259&event=96

_0707_alien-Az_ap+.bmsと比較してズレないことを確認しました。