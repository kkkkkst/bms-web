Nov. 24, 2019
7K sabun #11 | parry / parry(tarolabo)
- NORMAL 6
- HYPER 8
- ANOTHER 10

I really like this song. It feels like "sampling disco". The illustration that looks like an anatomy figure is also charming.

The way the keysounds were optimized for a 5K pattern meant I had to cut up a lot of them for the desired amount of keysounds. I feel sort of odd whenever I do it because it seems like it's messing with how the BMS was intended to be produced. tarolabo, you'll probably never read this but I'm sorry!

This song has a lot of different sections so the most important part was keeping the "feel" of them all right; eg making sure the big guitar hits feel good to hit. Overall it's a varied 10 with a pretty tough ending.

- hyso (Hyparpax)