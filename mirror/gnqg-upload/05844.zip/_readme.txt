本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=249&event=137
推定レベル：st8
jellyfish_noobj.bmsと比較してズレ抜け無し