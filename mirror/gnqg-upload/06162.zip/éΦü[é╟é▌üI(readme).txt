[この差分について]
本差分は元差分の全てのノーツ配置そのままに、
beatoraja対応版として修正を行ったものです。

beatoraja対応版作成にあたり、
元差分から下記4つの定義を削除してあります。
#SCROLL01 1
#SCROLL02 2
#SCROLL03 3
#SCROLL04 4

[元差分URL]
https://gnqg.rosx.net/upload/upload.cgi?get=5613