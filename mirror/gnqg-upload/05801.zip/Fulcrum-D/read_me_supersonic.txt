本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=332&event=137

難易度：★14？
NOTES：2117
TOTAL：570


こんにちは、unknown "ν" ことhyukiです。
本差分をDLしてくださりありがとうございます。
Lemi.さんの"Fulcrum-D"で発狂差分を作成してみました。BOFXVIIの曲を聴いて回っていた際に「これは......！」となりました。壮大すぎる曲調がとても刺さる！

一部、元の音源と異なる部分がありますが、仕様となります。（32分ズレのBGMオブジェクトを、ズレなしで配置しています）


また、開幕と中盤そして終盤にある小節線とBPM表示の演出は、BGAを担当されているraiiさんの譜面をリスペクトしたものとなっております。リスペクト元であるraiiさんのBMSも是非チェック！！！

【リスペクト元】
動画：https://www.youtube.com/watch?v=--QDJJ_0iGA
DL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=88&event=116
（Satellite難易度表sl9にも登載されています）