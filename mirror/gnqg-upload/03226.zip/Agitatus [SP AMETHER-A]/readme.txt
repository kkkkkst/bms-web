
IR http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=275963
BMS http://manbow.nothing.sh/event/event.cgi?action=More_def&num=41&event=115
���� http://ameria3141.web.fc2.com/bmssabun.html

