原譜面: ★15 REWD "B159 mix" // (kei-unmeasured 7)
リメイク譜面: ★15 REWD "B159 mix" [Rising]
リメイクした理由: 原譜面は連打が殆ど無い乱打譜面であったが、本曲のリズム感を連打で体感できる譜面をプレイしてみたかったためリメイクしました。
本体URL: http://web.archive.org/web/20031006164221/http://www.bmsjournal.net/lvo/rewd.rar
コメント: 追加音源が同梱されています。