URL : https://t.co/EKZei1vLg1
Difficulty : ★9~★11(sl6)?

comment
追加されている不可視オブジェクトは意図的なものです。
通常にプレイすれば原曲とのズレは発生しません。