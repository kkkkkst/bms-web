URL : http://gensoukyousoukyoku.nekokan.dyndns.info/9-TOMAX_remixed_by_LU-contact_force_sence.rar

Difficulty : st7(★★5)?